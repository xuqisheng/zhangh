##############################################################################
# usage:    ./install.sh [-c] 
#           1.Login as root
#           2.cd /home/sybase/mode
#           3.type ./install.sh or ./install.sh -c
#             -c means clearing cache configuration  
# functions:
#           1.configure shared memory information in linux and sybase;
#           2.configure sybase interfaces file;
#           3.add xrserver service to init.d scripts;
#             (xrservr service is used to start and stop sybase sql server)
#           4.add vsftpd service to init.d scripts for suse linux;
#             (vsftpd is a sub-service of xinetd service in suse linux
#               by default)
#           5.configure vsftpd.conf and coordinate vsftpd and xinetd services
#           6.set cron jobs for dump,load and ftp tasks; 
# remarks: 
#           1.xrserver,xinetd,vsftpd,crond can run on runlevels 2,3,4 or 5 on neoshine linux
#           2.xrserver,xinetd,vsftpd,cron  can run on runlevels 2,3 or 5 on suse linux.
#             DON'T change to runlevel 4 on which most services are not running.
#                                                  --hry-- 2008-12-12
##############################################################################
              
#import environment variables for sybase ase-12.5
. /home/sybase/mode/ndase12

#check authority
if [ "$HOME" != "/root" -a "$HOME" != "/" ]; then
   echo "You must login as root" && exit 1
fi
#add group sybase if needed,now only for suse linux systems
if [ -f /etc/sysconfig/suseconfig ]; then
   groupadd sybase 2>/dev/null
   usermod -g sybase sybase 2>/dev/null
fi

# need password comformation to run install.sh for sco

if [ -x /etc/ifconfig ]; then
   echo -n "Password confirmation:"
   read HINSTPASS
   [ "$HINSTPASS" != "iknowthedanger" ] && exit 1
fi

# record log
echo "####### run ./install.sh $1 ###########" >> /home/sybase/mode/logs/dumpload.log
echo                                           >> /home/sybase/mode/logs/dumpload.log
echo "`date`"                                  >> /home/sybase/mode/logs/dumpload.log
echo                                           >> /home/sybase/mode/logs/dumpload.log
chown sybase /home/sybase/mode/logs/dumpload.log

#check runlevel

[ -x /etc/ifconfig ] &&
{
if who -r|sed -e "s/^.*run-level \(.\).*$/\1/"|grep -E "[234]" >/dev/null; then
   :
else
   echo "You must be in runlevel 2,3 or 4" && exit 1
fi
}

[ ! -x /etc/ifconfig ] &&
{
INCLEVEL4="4" && INCLEVELF=",4"
[ -f /etc/sysconfig/suseconfig ] && INCLEVEL4="" && INCLEVELF=""

if (echo "`/sbin/runlevel`"  | grep -E  "[23${INCLEVEL4}5]$" > /dev/null); then
   :
else
   echo "You must be in runlevel 2,3${INCLEVELF} or 5" && exit 1
fi
}

# tmp file used later.

TMPFILE="/home/sybase/mode/tmp/hryinstall$$.tmp"
 
# get ip addresses of our needs
 
. /home/sybase/mode/getip

if [ -z "$HINSTIP" ]; then
   echo "Couldn't obtain desired ip address.Please check network setup." && exit 1
fi
if [ -n "$HSYBRUNIP" ]; then
   [ ! -x /etc/ifconfig ] &&
   {
   if [ "$HINSTIP" != "$HSYBRUNIP" ]; then
      if /sbin/ifconfig | grep "$HSYBRUNIP" > /dev/null 2>&1 ; then
        /home/sybase/mode/modintip "$HSYBRUNIP"
        echo "Please shutdown sybase sql server first" && exit 1
      else
        if [ "$1" = "--shutdown" ]; then
           /sbin/ifconfig eth0:5 "$HSYBRUNIP" up
           /home/sybase/mode/modintip "$HSYBRUNIP"
           /home/sybase/mode/xrserver stop  
           /sbin/ifconfig eth0:5 "$HSYBRUNIP" down
        else
           echo "Sybase shutdown is needed to continue installation."
           echo "When prepared,run \"./install.sh --shutdown\" to install" && exit 1
        fi
      fi
   fi
   }
fi

#add ip and hostname  to /etc/hosts

# look for /etc/sysconfig/network first

if [ -f /etc/sysconfig/network ]; then
   HNHOST=`cat /etc/sysconfig/network | grep -E "^HOSTNAME=" | sed -e "s/^HOSTNAME=\(.*\)/\1/"`
   [ -z "$HNHOST" -o "$HNHOST" = "localhost" -o "$HNHOST" = "localhost.localdomain" ] && HNHOST=""
fi
if [ -n "$HNHOST" ]; then
   if [ -z "$HINSTIPSTA" ]; then
      sed -e "/^[0-9\.]\{1,\}[ \t]\{1,\}$HNHOST[ \t]\{1,\}/d" /etc/hosts > $TMPFILE
      cp $TMPFILE /etc/hosts
   fi
fi

# get old name

HHOST="`grep $HINSTIP /etc/hosts |sed -e 's/^[0-9\.]\{1,\}[ \t]\{1,\}\([^ \t]\{1,\}\).*$/\1/g'`"
HHOST=`echo $HHOST | sed "s/^\([^\.]\{1,\}\).*$/\1/"`

if [ -z "$HHOST" -o "$HHOST" = "$HINSTIP" ] || (echo $HHOST | grep -E -e "fox[0-9]+-[0-9]+" > /dev/null); then
   HHOST="fox`echo $HINSTIP | sed -e 's/^[0-9]\{1,\}\.[0-9]\{1,\}\.//' -e 's/\./-/'`"
fi 
[ -n "$HNHOST" -a -z "$HINSTIPSTA" ] && HHOST=$HNHOST
[ -z "$HNHOST" ] && HNHOST=$HHOST

# insert a line 

sed -e "/^$HINSTIP[ \t]\{1,\}/d" /etc/hosts > $TMPFILE
if [ -f /etc/sysconfig/suseconfig ]; then
   echo "$HINSTIP	$HHOST.$HHOST	$HHOST" >>  $TMPFILE
   echo  "$HHOST.$HHOST" > /etc/HOSTNAME
else
   if [ -z "$HINSTIPSTA" ]; then
      echo "$HINSTIP	$HHOST	$HHOST" >>  $TMPFILE
   else
      echo "$HINSTIP	$HHOST" >>  $TMPFILE
   fi
fi
cp $TMPFILE /etc/hosts

# set hostname 

hostname $HNHOST
if [ -f /etc/sysconfig/network -a -z "$HINSTIPSTA" ]; then
   cat /etc/sysconfig/network | sed -e "s/^HOSTNAME=.*/HOSTNAME=$HNHOST/" > $TMPFILE
   cat $TMPFILE > /etc/sysconfig/network 
fi 

if [ -n "$HSYSAM" ]; then
   cd /home/sybase/$HSYSAM/licenses
   sed -e "s/^SERVER .* ANY/SERVER `hostname` ANY/g" ./license.dat > $TMPFILE
   cp $TMPFILE license.dat
   cd /home/sybase
fi

#Sybase interfaces
#backup interfaces file first

/home/sybase/mode/modintip "$HINSTIP"

#Get,calculate and set memory information

. /home/sybase/mode/cpumem

#configure shared memory

if [ -x /etc/ifconfig ]; then
   cat /etc/conf/sdevice.d/aio > $TMPFILE
   sed "s/[nN]/Y/g" $TMPFILE > /etc/conf/sdevice.d/aio
   cat /etc/conf/sdevice.d/suds > $TMPFILE
   sed "s/[nN]/Y/g" $TMPFILE > /etc/conf/sdevice.d/suds
   /etc/conf/bin/idtune -f SHMMAX $HSHMMAX
   /etc/conf/cf.d/link_unix
else
   #configure /etc/sysctl.conf
   [ ! -e /etc/sysctl.conf ] && touch /etc/sysctl.conf
   [ -x /etc/init.d/boot.sysctl ] && /sbin/chkconfig boot.sysctl on
   if [ -n "`cat /etc/sysctl.conf | grep '^kernel.shmmax='`" ]; then
      cp /etc/sysctl.conf $TMPFILE 
      sed -e "s/^\(kernel.shmmax=\).*/\1$HSHMMAX/g" $TMPFILE > /etc/sysctl.conf 
   else
      echo "kernel.shmmax=$HSHMMAX" >> /etc/sysctl.conf
   fi
   #The following statment will take effect immediately till system shutdown.
   #When linux system boots,value in /proc/sys/kernel/shmmax will be replaced by 
   #the kernel.shmmax value in /etc/sysctl.conf 
   #     ----Remarked by hry -----
   echo "$HSHMMAX" > /proc/sys/kernel/shmmax
fi

#SYBASE.cfg
#backup SYBASE.cfg file first

HTAIL=`ls -l /home/sybase/SYBASE.??? | grep -E "[0-9]{3}$" | sed -n '$ p'`
HTAIL=`echo $HTAIL | sed -e 's/.*\.//'`
HTAIL=`expr 0$HTAIL + 10001 | sed 's/^..//'`
SYBFILE="/home/sybase/$HASESUB/$HSYBASE.$HTAIL"

#
cd /home/sybase/$HASESUB
cp $HSYBASE.cfg $SYBFILE
HCLRCACHE="no"
[ "$1" = "-c" ] && HCLRCACHE=""
HSETDEVICES=""
[ -x /etc/ifconfig ] && HSETDEVICES="no"
cat $SYBFILE | 
sed -e "s/\(cache size ${HCLRCACHE}=\).*/\1 DEFAULT/g" |
sed -e "s/\(number of devices ${HSETDEVICES}=\).*$/\1 $HSYBDEVN/g" |
sed -e "s/\(max online engines =\).*$/\1 $HSYBCPU/g" |
sed -e "s/\(number of engines at startup =\).*$/\1 $HSYBCPU/g" |
sed -e "s/\(allocate max shared memory =\).*$/\1 1/g" |
sed -e "s/\(total memory =\).*$/\1 $HSYBMEM/" | 
sed -e "s/\(max memory =\).*$/\1 $HSYBMEM/" > $HSYBASE.cfg
cmp $SYBFILE SYBASE.cfg >/dev/null 2>&1 && rm -f $SYBFILE
chown sybase $HSYBASE.cfg
chgrp sybase $HSYBASE.cfg

#configure sybase sqlserver start/stop script

[ -x /etc/ifconfig ] &&
{
if [ -d /etc/rc2.d ]; then
   echo "/etc/suds_ctrl -a 100" > /etc/rc2.d/S999hry
   echo "/home/sybase/mode/xrserver start" >> /etc/rc2.d/S999hry
fi
[ -d /etc/rc3.d ] && echo "/home/sybase/mode/xrserver start" > /etc/rc3.d/S999hry
[ -d /etc/rc4.d ] && echo "/home/sybase/mode/xrserver start" > /etc/rc4.d/S999hry
[ -d /etc/rc0.d ] && echo "/home/sybase/mode/xrserver stop " > /etc/rc0.d/K24hry
[ -d /etc/rc1.d ] && echo "/home/sybase/mode/xrserver stop " > /etc/rc1.d/K24hry
[ -d /etc/rc5.d ] && echo "/home/sybase/mode/xrserver stop " > /etc/rc5.d/K24hry
[ -d /etc/rc6.d ] && echo "/home/sybase/mode/xrserver stop " > /etc/rc6.d/K24hry
}
[ ! -x /etc/ifconfig ] &&
{
chgrp sybase /var/lock/subsys
chmod g+rwx  /var/lock/subsys
if echo "$HINSTIPSTA" | grep float >/dev/null; then
   /sbin/chkconfig --del xrserver >/dev/null 2>&1
   rm -f /etc/init.d/xrserver
else
   rm -f /etc/init.d/xrserver;ln -s /home/sybase/mode/xrserver /etc/init.d/xrserver
   /sbin/chkconfig --add xrserver >/dev/null 2>&1
   /sbin/chkconfig --level 23${INCLEVEL4}5 xrserver on >/dev/null 2>&1
fi
if [ -d /etc/init.d/rc0.d ]; then
   if [ -z "`grep -E \"RUN_PARALLEL='no'\" < /etc/init.d/rc`" ]; then
      cp /etc/init.d/rc $TMPFILE 
      sed -e "s/\(# Stop\/Start services to\)/RUN_PARALLEL='no'\n\1/" $TMPFILE > /etc/init.d/rc 
   fi
fi
}

[ ! -x /etc/ifconfig ] &&
{
# timezone setup
/home/sybase/mode/settz

# disable SELINUX

if [ -f /etc/sysconfig/selinux ]; then
   cp /etc/sysconfig/selinux $TMPFILE
   cat $TMPFILE | sed -e "/^SELINUX=/d" > /etc/sysconfig/selinux
   echo "SELINUX=disabled" >> /etc/sysconfig/selinux
fi
 
# vsftpd setup

#recover the configuration file
if [ ! -d /etc/vsftpd ]; then
   if [ -f /etc/vsftpd.conf ]; then
      if cat /etc/vsftpd.conf | grep -E "anon_root=/home/sybase/dump" >/dev/null ; then
         cp /home/sybase/mode/impfile/suse/vsftpd.conf /etc 2>/dev/null
         chown root:root /etc/vsftpd.conf
         chmod 600       /etc/vsftpd.conf
      fi
   else
      echo "ftp server(vsftpd) has not been installed!Installation will not continue." && exit 1
   fi
fi

. /home/sybase/mode/dispmode > /dev/null

# configure vsftpd.conf first
cp /$WITHVSFTPD/vsftpd.conf $TMPFILE
cat $TMPFILE | 
sed -e "/^\(write\|local\)_enable=\([nN][oO]\|[yY][eE][sS]\)$/d" | 
sed -e "/^ascii_\(up\|down\)load_enable=\([nN][oO]\|[yY][eE][sS]\)$/d" | 
sed -e "/^use_localtime=/d" | 
sed -e "/^local_umask=/d" > /$WITHVSFTPD/vsftpd.conf
echo "use_localtime=YES" >>          /$WITHVSFTPD/vsftpd.conf
echo "write_enable=YES" >>          /$WITHVSFTPD/vsftpd.conf
echo "local_enable=YES" >>          /$WITHVSFTPD/vsftpd.conf
echo "ascii_upload_enable=YES" >>   /$WITHVSFTPD/vsftpd.conf
echo "ascii_download_enable=YES" >> /$WITHVSFTPD/vsftpd.conf
echo "local_umask=022" >>           /$WITHVSFTPD/vsftpd.conf

# check vsftpd mode(standalone or xinetd mode) and correct conflicting setting

# if there is no standalone vsftpd,copy our vsftpd to /etc/init.d

if [ ! -f /etc/init.d/vsftpd ]; then
   cp /home/sybase/mode/vsftpd /etc/init.d/vsftpd
elif grep xrserver /etc/init.d/vsftpd >/dev/null 2>&1 ; then
   cp /home/sybase/mode/vsftpd /etc/init.d/vsftpd
fi
/sbin/chkconfig --add vsftpd >/dev/null 2>&1
/sbin/chkconfig --level 23${INCLEVEL4}5 xinetd on > /dev/null 2>&1
/sbin/chkconfig --level 23${INCLEVEL4}5 vsftpd on > /dev/null 2>&1

if [ -f /etc/xinetd.d/vsftpd ]; then
   case "$SMODE$XMODE" in
   00)
      /etc/init.d/xinetd stop >/dev/null 2>&1
      /etc/init.d/vsftpd stop >/dev/null 2>&1 
      if [ -x /etc/init.d/vsftpd -a -n "`ls /etc/rc.d/rc?.d/???vsftpd 2>/dev/null`" ]; then
         cp /$WITHVSFTPD/vsftpd.conf $TMPFILE
         cat $TMPFILE | sed -e "/^listen=[nN][oO]$/d"  -e "$ alisten=YES" > /$WITHVSFTPD/vsftpd.conf
         /etc/init.d/vsftpd start >/dev/null 2>&1 
      else
         sed -e "s/^\([ \t]*disable *= *\)yes/\1no/g"  /etc/xinetd.d/vsftpd > $TMPFILE
         cp $TMPFILE /etc/xinetd.d/vsftpd
      fi
      /etc/init.d/xinetd start >/dev/null 2>&1 
      ;;
   01)
      :
      ;;
   10)
      if [ ! -x /etc/init.d/vsftpd -o -z "`ls /etc/rc.d/rc?.d/???vsftpd 2>/dev/null`" ]; then
         sed -e "s/^\([ \t]*disable *= *\)yes/\1no/g"  /etc/xinetd.d/vsftpd > $TMPFILE
         cp $TMPFILE /etc/xinetd.d/vsftpd
         sed -e "/^listen=[yY][eE][sS]$/d" /$WITHVSFTPD/vsftpd.conf > $TMPFILE
         cp $TMPFILE /$WITHVSFTPD/vsftpd.conf
         test -f /etc/init.d/vsftpd && /etc/init.d/vsftpd stop
         /etc/init.d/xinetd restart 
      else
         /etc/init.d/xinetd restart >/dev/null 2>&1 
         /etc/init.d/vsftpd restart >/dev/null 2>&1 
      fi 
      ;;
   11)
      if [ -x /etc/init.d/vsftpd -a -n "`ls /etc/rc.d/rc?.d/???vsftpd 2>/dev/null`" ]; then
         cat /etc/xinetd.d/vsftpd > $TMPFILE
         if [ -n "`cat $TMPFILE | grep -E  '^[	 ]*disable *= *no *$'`" ]; then
            cat $TMPFILE | sed -e "s/^\([ \t]*disable *= *\)no/\1yes/g" > /etc/xinetd.d/vsftpd
         else
            cat $TMPFILE | sed -e "s/{/{\n\tdisable = yes/g" > /etc/xinetd.d/vsftpd
         fi
         /etc/init.d/xinetd restart
         /etc/init.d/vsftpd start 
      else
         sed -e "/^listen=[yY][eE][sS]$/d" /$WITHVSFTPD/vsftpd.conf > $TMPFILE
         cp $TMPFILE /$WITHVSFTPD/vsftpd.conf
         test -f /etc/init.d/vsftpd && /etc/init.d/vsftpd stop
         /etc/init.d/xinetd restart 
      fi
      ;;
   esac
else
   if [ $SMODE = "0" ]; then
      if [ -x /etc/init.d/vsftpd -a -n "`ls /etc/rc.d/rc?.d/???vsftpd 2>/dev/null`" ]; then
         cat /$WITHVSFTPD/vsftpd.conf | 
         sed -e "/^listen=[nN][oO]$/d"  -e "$ alisten=YES" > $TMPFILE
         cp $TMPFILE /$WITHVSFTPD/vsftpd.conf
         /etc/init.d/vsftpd start
      fi
   else
      /etc/init.d/vsftpd restart >/dev/null
   fi
fi


# comment LC_ALL,LC_CTYPE and LANG  setting in /home/sybase/.bash_profile
# remove . from PATH for security 

cp /home/sybase/.bash_profile $TMPFILE
cat $TMPFILE | 
sed -e "s/^\(LC_ALL\|LC_CTYPE\|LANG\)=/#\1=/" | 
sed -e "s/^\(PATH=\)\.[^:]*:\(.*\)/\1\2/"   |
sed -e "s/\(\$SYBASE\/bin\):\(\$PATH\)/\1:\$SYBASE\/install:\2/"  > /home/sybase/.bash_profile

# set locale

if [ -d "/etc/vsftpd" ]; then
   echo "LC_CTYPE=zh_CN.GB18030" >  /etc/sysconfig/i18n
   echo "SYSFONT=lat0-sun16"     >> /etc/sysconfig/i18n
   echo "LANG=en_US"             >> /etc/sysconfig/i18n
else
   cat /etc/sysconfig/language |  
   sed -e "/^\(ROOT_USES_LANG\|RC_LC_ALL\|RC_LC_CTYPE\|RC_LANG\)=/ d"  >  $TMPFILE
   cat $TMPFILE > /etc/sysconfig/language
   echo "ROOT_USES_LANG=\"yes\""                    >> /etc/sysconfig/language
   echo "RC_LC_ALL=\"\""                            >> /etc/sysconfig/language
   echo "RC_LC_CTYPE=\"zh_CN.GB2312\""              >> /etc/sysconfig/language
   echo "RC_LANG=\"C\""                             >> /etc/sysconfig/language
fi
rm -f /home/sybase/.i18n
}
[ -x /etc/ifconfig ] &&
{
if grep "LANG=english_us.8859" /home/sybase/.profile >/dev/null; then
   :
else
   echo "LANG=english_us.8859" >> /home/sybase/.profile
   echo "export LANG"          >> /home/sybase/.profile
fi
if grep "LANG=english_us.8859" /.profile >/dev/null; then
   :
else
   echo "LANG=english_us.8859" >> /.profile
   echo "export LANG"          >> /.profile
fi
}

#cron(auto dump/load/ftp)

if [ -x /etc/ifconfig ]; then
   WITHTABS="usr/spool/cron/crontabs"
else
   WITHTABS="var/spool/cron"
   if [ -d /var/spool/cron/tabs ]; then
      WITHTABS="var/spool/cron/tabs"
   fi
fi

# modified to support multiserver mutual backup
# modified to support engineering aid and check 
# conditional writing of crontab
HWRITECRONTAB='1'
# cover or not
if [ -f /$WITHTABS/sybase ]; then
   if [ `cat /$WITHTABS/sybase | grep exectask | wc -l` -eq 0 ]; then
      HWRITECRONTAB='1'
   elif cat /$WITHTABS/sybase | sed "/^#/ d" | grep -vE "^0 [24569\*] \* \* \* (ba)?sh /home/sybase/mode/exectask (dump|ftpg|ftpget|load|each|engm)$" >/dev/null; then
      HWRITECRONTAB='0'
   elif cat /$WITHTABS/sybase | sed "/^#/ d" | grep -vE "^0 (2.*dump|4.*ftpg|5.*ftpget|6.*load|9.*each|\*.*engm)$" >/dev/null; then
      HWRITECRONTAB='0'
   fi
fi
if [ "$HWRITECRONTAB" = '1' ]; then
   echo "0 2 * * * sh /home/sybase/mode/exectask dump"        >  /$WITHTABS/sybase
   echo "0 4 * * * sh /home/sybase/mode/exectask ftpg"        >> /$WITHTABS/sybase
   echo "0 5 * * * sh /home/sybase/mode/exectask ftpget"      >> /$WITHTABS/sybase
   echo "0 6 * * * sh /home/sybase/mode/exectask load"        >> /$WITHTABS/sybase
   echo "0 15 * * * sh /home/sybase/mode/exectask dump"        >>  /$WITHTABS/sybase
   echo "0 16 * * * sh /home/sybase/mode/exectask ftpg"        >> /$WITHTABS/sybase
   echo "0 17 * * * sh /home/sybase/mode/exectask ftpget"      >> /$WITHTABS/sybase
   echo "0 18 * * * sh /home/sybase/mode/exectask load"        >> /$WITHTABS/sybase
   echo "0 9 * * * sh /home/sybase/mode/exectask each"        >> /$WITHTABS/sybase
   echo "0 * * * * sh /home/sybase/mode/exectask engm"        >> /$WITHTABS/sybase
fi
# set sysdate every one minute and set usbdump task
if [ ! -x /etc/ifconfig ]; then
   if [ -e /etc/crontab ]; then
      if cat /etc/crontab | grep "root hwclock -s" >/dev/null; then
         :
      else
         echo "*/5 * * * * root hwclock -s" >> /etc/crontab
      fi
      if cat /etc/crontab | grep "trandump" >/dev/null; then
         :
      else
         echo "0 8 * * * root sh /home/sybase/mode/exectask trandump" >> /etc/crontab
      fi
      if cat /etc/crontab | grep "hmon" >/dev/null; then
         :
      else
         echo "*/1 * * * * root sh /home/sybase/mode/hmon" >> /etc/crontab
      fi
   fi 
fi 
if [ -x /etc/ifconfig ]; then
   if [ -x /etc/init.d/cron ]; then
      /etc/init.d/cron stop  > /dev/null 2>&1 
      /etc/init.d/cron start > /dev/null 2>&1 
   fi
else
   test -x /etc/init.d/cron  &&
   /sbin/chkconfig --level 23${INCLEVEL4}5 cron on  && 
   /etc/init.d/cron  restart > /dev/null 2>&1 
   test -x /etc/init.d/crond && 
   /sbin/chkconfig --level 23${INCLEVEL4}5 crond on && 
   /etc/init.d/crond restart > /dev/null 2>&1 
fi



# add a symbolic link to /home/sybase/ASE-12_5/SYBASE.cfg for sybase 12.x
# DON'T use hard link!!!

if [ -n "$HASESUB" ]; then
   touch /home/sybase/$HASESUB/install/$HSYBASE.log
   touch /home/sybase/$HASESUB/install/$HSYBBACKUP.log
   chown sybase /home/sybase/$HASESUB/install/$HSYBASE.log
   chown sybase /home/sybase/$HASESUB/install/$HSYBBACKUP.log
   rm -f /home/sybase/$HSYBASE.cfg
   ln -s /home/sybase/$HASESUB/$HSYBASE.cfg /home/sybase/$HSYBASE.cfg
else
   touch /home/sybase/install/errorlog
   touch /home/sybase/install/backup.log
   chown sybase /home/sybase/install/errorlog
   chown sybase /home/sybase/install/backup.log
fi

# 

touch /home/sybase/mode/logs/each.log;touch /home/sybase/mode/logs/each_detail.log
touch /home/sybase/mode/logs/upgrade.log;touch /home/sybase/mode/logs/upgrade_detail.log
touch /home/sybase/mode/logs/hdck.log;touch /home/sybase/mode/logs/hdck_detail.log
touch /home/sybase/mode/logs/hmon.log

#
 
chown -R sybase:sybase /home/sybase 2>/dev/null
chown -R sybase:sybase /usr/sybase  2>/dev/null

# neccesary work 

if [ ! -x /etc/ifconfig ]; then
   # mv old mode
   [ ! -d /home/sybase/mode.old ] && mkdir /home/sybase/mode.old
   mv /home/sybase/mode/*.mode  /home/sybase/mode.old 2>/dev/null 
   mv /home/sybase/mode/*.mode~ /home/sybase/mode.old 2>/dev/null 
   # rm old mode installation
   rm -f /home/sybase/install.sh 
   rm -f /etc/rc.d/rc?.d/*shmmax
   rm -f /etc/rc.d/rc?.d/*closedb
   rm -f /etc/rc.d/shmmax
   rm -f /etc/rc.d/closedb
   if [ ! -f /etc/sysconfig/suseconfig ]; then
      # rc.local
      cat /etc/rc.d/rc.local | grep "^touch" > $TMPFILE;cp  $TMPFILE /etc/rc.d/rc.local
      # boot 
      #cat /boot/grub/grub.conf | sed -e "s/^default=.*$/default=0/" > $TMPFILE;cp  $TMPFILE /boot/grub/grub.conf
   else
      # .bash_profile 
      cat /home/sybase/.bash_profile | sed "/^\/home\/sybase/,$ d" > $TMPFILE;cp $TMPFILE /home/sybase/.bash_profile
   fi
fi

#remove tmpfile
rm -f $TMPFILE

# end of install.sh

echo "Installation successfully completed!"

