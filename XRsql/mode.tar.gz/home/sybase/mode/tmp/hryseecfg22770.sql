dump database foxhis 
       to '/home/sybase/dump/foxhis-3d4_2000-3d5_2000-3d6_2000-4d7_2000-3d8_2000-3d9_2000-3d10_2000.12-5-4-dat01' 
stripe on '/home/sybase/dump/foxhis-3d4_2000-3d5_2000-3d6_2000-4d7_2000-3d8_2000-3d9_2000-3d10_2000.12-5-4-dat02'
stripe on '/home/sybase/dump/foxhis-3d4_2000-3d5_2000-3d6_2000-4d7_2000-3d8_2000-3d9_2000-3d10_2000.12-5-4-dat03'
stripe on '/home/sybase/dump/foxhis-3d4_2000-3d5_2000-3d6_2000-4d7_2000-3d8_2000-3d9_2000-3d10_2000.12-5-4-dat04'
stripe on '/home/sybase/dump/foxhis-3d4_2000-3d5_2000-3d6_2000-4d7_2000-3d8_2000-3d9_2000-3d10_2000.12-5-4-dat05'
stripe on '/home/sybase/dump/foxhis-3d4_2000-3d5_2000-3d6_2000-4d7_2000-3d8_2000-3d9_2000-3d10_2000.12-5-4-dat06'

go
