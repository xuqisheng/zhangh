/* yjiedai of V1 - V4 - completeness check  */
/*
----each----:[yjiedai.date][yjiedai.last_bl1]
----each----:[#pccode][#ydairep.last_bl]
*/

select remark             = "Missing yjiedai data",
       from_inclusive    = convert(char(4),datepart(year,dateadd(dd,1,a.date)))+'/'+substring(convert(char(3),datepart(month,dateadd(dd,1,a.date))+100),2,2)+'/'+substring(convert(char(3),datepart(day,dateadd(dd,1,a.date))+100),2,2),
       to_inclusive      = convert(char(4),datepart(year,isnull((select min(dateadd(dd,-1,b.date)) from yjiedai b where b.date > a.date),(select c.bdate from accthead c))))+'/'+substring(convert(char(3),datepart(month,isnull((select min(dateadd(dd,-1,b.date)) from yjiedai b where b.date > a.date),(select c.bdate from accthead c)))+100),2,2)+'/'+substring(convert(char(3),datepart(day,isnull((select min(dateadd(dd,-1,b.date)) from yjiedai b where b.date > a.date),(select c.bdate from accthead c)))+100),2,2)
       from yjiedai a
       group by a.date
       having dateadd(dd,1,a.date) <= (select c.bdate from accthead c) and not exists(select 1 from yjiedai d where dateadd(dd,1,a.date) = d.date)
       order by a.date
