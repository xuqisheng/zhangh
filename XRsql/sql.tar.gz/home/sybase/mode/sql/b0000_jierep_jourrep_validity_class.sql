/* jierep_jourrep definition validity - class */
/*
----each----:[jierep.class]
----each----:[jierep_jourrep.class][jierep_jourrep.descript]
----each----:[jierep_jourrep.day01][jierep_jourrep.day02][jierep_jourrep.day03][jierep_jourrep.day04][jierep_jourrep.day05]
----each----:[jierep_jourrep.day06][jierep_jourrep.day07][jierep_jourrep.day08][jierep_jourrep.day09][jierep_jourrep.day99]
*/
select 
       a.class,a.descript,
       remark = "Missing corresponding row in jierep"
       from jierep_jourrep a
       where rtrim(a.day01+a.day02+a.day03+a.day04+a.day05+a.day06+a.day07+a.day08+a.day09+a.day99) is not null
             and not exists(select b.class from jierep b where b.class = a.class)
       order by a.class
