/* ydeptjie against ydeptdai check */
/*
----each----:[ydeptjie.date][ydeptjie.pccode][ydeptjie.shift][ydeptjie.empno][ydeptjie.code][ydeptjie.descript]
----each----:[ydeptjie.feed][ydeptjie.feem][ydeptjie.feey]
----each----:[ydeptdai.date][ydeptdai.pccode][ydeptdai.shift][ydeptdai.empno][ydeptdai.paycode]
----each----:[ydeptdai.creditd][ydeptdai.creditm][ydeptdai.credity]
*/
select a.pccode,
       date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.shift,a.empno,a.code,b.paycode,a.descript,
       a.feed,a.feem,a.feey,b.creditd,b.creditm,b.credity,
       diff_d=str(a.feed-b.creditd,15,3),
       diff_m=str(a.feem-b.creditm,15,3),
       diff_y=str(a.feey-b.credity,15,3)
       from ydeptjie a,ydeptdai b
       where a.shift='9' and a.empno='{{{' and b.shift='9' and b.empno='{{{' and (a.code='6' and b.paycode='C99' or a.code='999' and b.paycode='D99')
            and a.date = b.date and a.pccode = b.pccode and (a.feed-b.creditd <> 0 or a.feem-b.creditm <> 0 or a.feey-b.credity <> 0)
       order by a.pccode,a.date,a.shift,a.empno,a.code
