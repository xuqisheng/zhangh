/* pccode definition - deptno8 validity */
/*
----each----:[pccode.pccode][pccode.descript][pccode.descript1][pccode.deptno8]
*/
select a.pccode,a.descript,a.descript1,a.deptno8,
       remark = 'deptno8 not in accordance with description'
       from pccode a
       where ((
               rtrim(upper(a.descript1)) like '%REBATE%' or 
               rtrim(upper(a.descript1)) like '%ADJUST%' or
               rtrim(upper(a.descript))  like '%REBATE%' or
               rtrim(a.descript)         like '%����%'   or
               rtrim(a.descript)         like '%���%'   or
               rtrim(a.descript)         like '%����%'   or
               rtrim(a.descript)         like '%�ۼ�%'   or
               rtrim(a.descript)         like '%����%'
              )
              and a.deptno8 <> 'RB'
              or
              (
               rtrim(upper(a.descript1)) not like '%REBATE%' and  
               rtrim(upper(a.descript1)) not like '%ADJUST%' and
               rtrim(upper(a.descript))  not like '%REBATE%' and
               rtrim(a.descript)         not like '%����%'   and
               rtrim(a.descript)         not like '%���%'   and
               rtrim(a.descript)         not like '%����%'   and
               rtrim(a.descript)         not like '%�ۼ�%'   and
               rtrim(a.descript)         not like '%����%'
              )
              and a.deptno8  = 'RB'
             )
             and a.pccode < '9'
       order by a.pccode