/* yjiedai against ydairep - horizontal dc check - v3 - AR ledger */
/*
----each----:[ydairep.date][ydairep.tplace][ydairep.gback][ydairep.sumcre]
----each----:[yjiedai.date][yjiedai.debit_1][yjiedai.credit_1][yjiedai.debit_o][yjiedai.credit_o]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       dairep_debit_o =str((select isnull(sum(tplace),0) from ydairep b where b.date=a.date and b.class='03000'),15,3),
       dairep_credit_o=str((select isnull(sum(sumcre),0) from ydairep b where b.date=a.date and b.class='03999'),15,3),
       jiedai_debit_o =str((select isnull(sum(b.debit_o),0) from yjiedai b where a.date = b.date),15,3),
       jiedai_credit_o=str((select isnull(sum(b.credit_o),0) from yjiedai b where a.date = b.date),15,3),
       diff_debit_o   =str( (select isnull(sum(tplace),0) from ydairep b where b.date=a.date and b.class='03000') - (select isnull(sum(b.debit_o),0) from yjiedai b where a.date = b.date),15,3),
       diff_credit_o  =str( (select isnull(sum(sumcre),0) from ydairep b where b.date=a.date and b.class='03999') - (select isnull(sum(b.credit_o),0) from yjiedai b where a.date = b.date),15,3)

       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having ((select isnull(sum(gback),0)  from ydairep b where b.date=a.date and b.class='02000') - (select isnull(sum(b.credit_1),0) from yjiedai b where a.date = b.date) <> 0
               or
               (select isnull(sum(sumcre),0) from ydairep b where b.date=a.date and b.class='03999') - (select isnull(sum(b.credit_o),0) from yjiedai b where a.date = b.date) <> 0
              )
              and (select sum(b.debit_1+b.debit_o-b.credit_1-b.credit_o) from yjiedai b where a.date=b.date) is not null
       order by a.date