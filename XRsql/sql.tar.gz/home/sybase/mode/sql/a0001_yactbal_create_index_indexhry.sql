/* yact_bal - create an index indexhry */
/*
----each----:[yact_bal.date][yact_bal.accnt][yact_bal.tillbl]
*/
if not exists(select 1 from sysindexes where name='indexhry' and object_name(id)='yact_bal')
   create unique index indexhry on yact_bal(accnt,date)
