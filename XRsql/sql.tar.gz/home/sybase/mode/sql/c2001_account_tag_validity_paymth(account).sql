/* account.tag vs paymth.descript1 - validity check  */
/*
----each----:[account.accnt][account.number][account.inumber][account.bdate][account.pccode][account.servcode][account.tag][account.credit]
----each----:[paymth.descript1]
*/

select accnt,number,inumber,
       bdate=convert(char(4),datepart(year,a.bdate))+'/'+substring(convert(char(3),datepart(month,a.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.bdate)+100),2,2),
       pccode,servcode,tag,credit,
       remark="account.tag not defined in table paymth"
       from account a
       where rtrim(a.tag) is not null and a.pccode in ('03','05','06') and 
             not exists(select 1 from paymth b where a.tag = b.descript1)
       order by a.accnt,a.number