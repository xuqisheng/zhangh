/* pccode definition - deptno7 validity - charge part*/
/*
----each----:[pccode.pccode][pccode.descript][pccode.descript1][pccode.deptno7]
----each----:[basecode.cat][basecode.code]
*/
select a.pccode,a.descript,a.descript1,
       pccode_deptno7 = a.deptno7,
       remark = "deptno7 not in table basecode with cat='chgcod_deptno7'"
       from pccode a
       where pccode < '9' and not exists(select 1 from basecode b where b.cat='chgcod_deptno7' and b.code=a.deptno7)
       order by a.pccode