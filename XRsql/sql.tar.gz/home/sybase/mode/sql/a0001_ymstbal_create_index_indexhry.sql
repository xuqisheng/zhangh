/* ymstbalrep - create an index indexhry */
/*
----each----:[ymstbalrep.date][ymstbalrep.accnt][ymstbalrep.tillbl]
*/
if not exists(select 1 from sysindexes where name='indexhry' and object_name(id)='ymstbalrep')
   create unique index indexhry on ymstbalrep(accnt,date)
