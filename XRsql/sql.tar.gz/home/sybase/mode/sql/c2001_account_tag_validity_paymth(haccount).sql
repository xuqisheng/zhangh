/* haccount.tag vs paymth.descript1 - validity check  */
/*
----each----:[haccount.accnt][haccount.number][haccount.inumber][haccount.bdate][haccount.pccode][haccount.servcode][haccount.tag][haccount.credit]
----each----:[paymth.descript1]
*/

select accnt,number,inumber,
       bdate=convert(char(4),datepart(year,a.bdate))+'/'+substring(convert(char(3),datepart(month,a.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.bdate)+100),2,2),
       pccode,servcode,tag,credit,
       remark="haccount.tag not defined in table paymth"
       from haccount a
       where rtrim(a.tag) is not null and a.pccode in ('03','05','06') and 
             not exists(select 1 from paymth b where a.tag = b.descript1)
       order by a.accnt,a.number