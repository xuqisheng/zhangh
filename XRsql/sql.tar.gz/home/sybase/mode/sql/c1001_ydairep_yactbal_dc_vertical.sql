/* yact_bal against ydairep - vertical dc check */
/*
----each----:[ydairep.date][ydairep.last_bl][ydairep.till_bl]
----each----:[yact_bal.date][yact_bal.lastbl][yact_bal.tillbl]
*/

select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       dairep_bl=str(isnull(sum(a.till_bl),0),15,3),
       actbal_bl=str((select isnull(sum(b.tillbl),0) from yact_bal b where a.date=b.date),15,3),
       dairep_dc_v=str((isnull(sum(a.till_bl),0)-(select isnull(sum(b.till_bl),0) from ydairep b where b.date=dateadd(dd,-1,a.date) and (b.class='02000' or b.class='03000'))),15,3),
       actbal_dc_v=str((select isnull(sum(b.tillbl),0) from yact_bal b where a.date=b.date) - (select isnull(sum(b.tillbl),0) from yact_bal b where b.date=dateadd(dd,-1,a.date)),15,3),
       diff=str((isnull(sum(a.till_bl),0)-(select isnull(sum(b.till_bl),0) from ydairep b where b.date=dateadd(dd,-1,a.date) and (b.class='02000' or b.class='03000')))-((select isnull(sum(b.tillbl),0) from yact_bal b where a.date=b.date) - (select isnull(sum(b.tillbl),0) from yact_bal b where b.date=dateadd(dd,-1,a.date))),15,3)
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having ((isnull(sum(a.till_bl),0)-(select isnull(sum(b.till_bl),0) from ydairep b where b.date=dateadd(dd,-1,a.date) and (b.class='02000' or b.class='03000')))-
               ((select isnull(sum(b.tillbl),0) from yact_bal b where a.date=b.date) - (select isnull(sum(b.tillbl),0) from yact_bal b where b.date=dateadd(dd,-1,a.date)))) <> 0 
              and (select sum(b.tillbl) from yact_bal b where a.date=b.date) is not null
              and (select sum(b.tillbl) from yact_bal b where b.date=dateadd(dd,-1,a.date)) is not null
       order by a.date
            