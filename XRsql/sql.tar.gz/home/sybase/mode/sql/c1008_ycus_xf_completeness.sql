/* ycus_xf against ydairep - completeness check  */
/*
----each----:[ydairep.date][ydairep.last_bl][ydairep.debit][ydairep.credit][ydairep.till_bl]
----each----:[ycus_xf.date][ycus_xf.sta][ycus_xf.lastd][ycus_xf.lastc][ycus_xf.tilld][ycus_xf.tillc]
*/

select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       remark='Missing balance data'
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having sum(abs(a.last_bl)+abs(a.debit)+abs(a.credit)+abs(a.till_bl)) <> 0
              and not exists(select 1 from ycus_xf b where a.date = b.date  and rtrim(b.sta) is not null)
              and exists(select 1 from ycus_xf b where rtrim(b.sta) is not null)
       order by a.date

