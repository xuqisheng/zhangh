/* yact_bal detail consistency check - ttd data */
/*
----each----:[yact_bal.date][yact_bal.accnt][yact_bal.name]
----each----:[yact_bal.ttd01][yact_bal.ttd02][yact_bal.ttd03][yact_bal.ttd04][yact_bal.ttd05][yact_bal.ttd06]
----each----:[yact_bal.ttd07][yact_bal.ttd08][yact_bal.ttd09][yact_bal.ttd10][#yact_bal.ttd11][#yact_bal.ttd12]
----each----:[yact_bal.ttd99]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.accnt,a.name,
       a.ttd01,a.ttd02,a.ttd03,a.ttd04,a.ttd05,a.ttd06,a.ttd07,a.ttd08,a.ttd09,a.ttd10,
       sum01_10=str((a.ttd01+a.ttd02+a.ttd03+a.ttd04+a.ttd05+a.ttd06+a.ttd07+a.ttd08+a.ttd09+a.ttd10),15,3),
       a.ttd99,
       diff=str((a.ttd01+a.ttd02+a.ttd03+a.ttd04+a.ttd05+a.ttd06+a.ttd07+a.ttd08+a.ttd09+a.ttd10)-a.ttd99,15,3)
       from yact_bal a
       where (a.ttd01+a.ttd02+a.ttd03+a.ttd04+a.ttd05+a.ttd06+a.ttd07+a.ttd08+a.ttd09+a.ttd10)-a.ttd99 <> 0
       order by a.date,a.accnt
