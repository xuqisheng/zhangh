/* pos_detail_jie against pos_detail_dai check */
/*
----each----:[pos_hmenu.bdate][pos_hmenu.pcrec][pos_hmenu.menu][pos_hmenu.pccode][pos_hmenu.shift]
----each----:[pos_detail_jie.menu][pos_detail_jie.amount0][pos_detail_jie.amount1][pos_detail_jie.amount2][pos_detail_jie.amount3][pos_detail_jie.type]
----each----:[pos_detail_dai.menu][pos_detail_dai.amount]
*/
select 
       bdate=convert(char(4),datepart(year,a.bdate))+'/'+substring(convert(char(3),datepart(month,a.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.bdate)+100),2,2),
       a.pcrec,a.menu,a.pccode,a.shift,
       jie_amount=str((select isnull(sum(b.amount0-b.amount1-b.amount2-b.amount3),0) from pos_detail_jie b where b.menu = a.menu and b.type<'9'),15,3),
       dai_amount=str((select isnull(sum(c.amount ),0) from pos_detail_dai c where c.menu = a.menu),15,3),
       diff      =str((select isnull(sum(b.amount0-b.amount1-b.amount2-b.amount3),0) from pos_detail_jie b where b.menu = a.menu and b.type<'9')-(select isnull(sum(c.amount),0) from pos_detail_dai c where c.menu = a.menu),15,3)
from pos_hmenu a
where (select isnull(sum(b.amount0-b.amount1-b.amount2-b.amount3),0) from pos_detail_jie b where b.menu = a.menu and b.type<'9') <>
      (select isnull(sum(c.amount ),0) from pos_detail_dai c where c.menu = a.menu)
order by a.pcrec,a.pccode,a.menu
