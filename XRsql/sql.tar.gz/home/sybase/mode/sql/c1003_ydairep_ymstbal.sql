/* ymstbalrep against ydairep balance check - tillbl */
/*
----each----:[ymstbalrep.date][ymstbalrep.tillbl]
----each----:[ydairep.date][ydairep.till_bl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       dairep=str(isnull(sum(a.till_bl),0),15,3),
       mstbalrep=str((select isnull(sum(b.tillbl),0) from ymstbalrep b where a.date=b.date),15,3),
       diff=str(isnull(sum(a.till_bl),0)-(select isnull(sum(b.tillbl),0) from ymstbalrep b where a.date=b.date),15,3)
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having (isnull(sum(a.till_bl),0)-(select isnull(sum(b.tillbl),0) from ymstbalrep b where a.date=b.date)) <> 0
              and (select sum(b.tillbl) from ymstbalrep b where a.date=b.date) is not null
       order by a.date
