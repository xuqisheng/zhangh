/* ycus_xf against ydairep balance check - tillbl */
/*
----each----:[ycus_xf.date][ycus_xf.sta][ycus_xf.tillbl]
----each----:[ydairep.date][ydairep.till_bl]
*/

select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       dairep=str(isnull(sum(a.till_bl),0),15,3),
       ycusxf=str((select isnull(sum(b.tillbl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null),15,3),
       diff=str(isnull(sum(a.till_bl),0)-(select isnull(sum(b.tillbl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null),15,3)
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having (isnull(sum(a.till_bl),0)-(select isnull(sum(b.tillbl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null)) <> 0 
              and (select sum(b.tillbl) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null) is not null
       order by a.date
