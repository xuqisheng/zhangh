/* pccode definition - deptno8 validity */
/* here deptno8 is used for pos system  */
/*
----each----:[pccode.pccode][pccode.descript][pccode.descript1][pccode.deptno8]
*/
select a.pccode,a.descript,a.descript1,a.deptno8,
       remark = 'Duplicate deptno8 is not allowed here'
       from pccode a
       where a.deptno8 like '[0-9][0-9][0-9]' and 
             (select count(1) from pccode b where b.deptno8 = a.deptno8) > 1 
       order by a.pccode
