/* yact_bal detail consistency check - tcrd data */
/*
----each----:[yact_bal.date][yact_bal.accnt][yact_bal.name]
----each----:[yact_bal.tcrd01][yact_bal.tcrd02][yact_bal.tcrd03][yact_bal.tcrd04][yact_bal.tcrd05]
----each----:[yact_bal.tcrd99]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.accnt,a.name,
       a.tcrd01,a.tcrd02,a.tcrd03,a.tcrd04,a.tcrd05,
       sum01_05=str((a.tcrd01+a.tcrd02+a.tcrd03+a.tcrd04+a.tcrd05),15,3),
       a.tcrd99,
       diff=str((a.tcrd01+a.tcrd02+a.tcrd03+a.tcrd04+a.tcrd05)-a.tcrd99,15,3)
       from yact_bal a
       where (a.tcrd01+a.tcrd02+a.tcrd03+a.tcrd04+a.tcrd05)-a.tcrd99 <> 0
       order by a.date,a.accnt
