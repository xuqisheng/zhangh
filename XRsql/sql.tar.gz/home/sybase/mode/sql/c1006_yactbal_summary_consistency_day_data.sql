/* yact_bal summary consistency check - day data*/
/*
----each----:[yact_bal.date]
----each----:[yact_bal.day01][yact_bal.day02][yact_bal.day03][yact_bal.day04][yact_bal.day05][yact_bal.day06]
----each----:[yact_bal.day07][yact_bal.day08][yact_bal.day09][yact_bal.day10][yact_bal.day11][yact_bal.day12]
----each----:[yact_bal.day99]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       day01=str(isnull(sum(a.day01),0),15,3),
       day02=str(isnull(sum(a.day02),0),15,3),
       day03=str(isnull(sum(a.day03),0),15,3),
       day04=str(isnull(sum(a.day04),0),15,3),
       day05=str(isnull(sum(a.day05),0),15,3),
       day06=str(isnull(sum(a.day06),0),15,3),
       day07=str(isnull(sum(a.day07),0),15,3),
       day08=str(isnull(sum(a.day08),0),15,3),
       day09=str(isnull(sum(a.day09),0),15,3),
       day10=str(isnull(sum(a.day10),0),15,3),
       day11=str(isnull(sum(a.day11),0),15,3),
       day12=str(isnull(sum(a.day12),0),15,3),
       sum01_12=str(isnull(sum(a.day01),0)+isnull(sum(a.day02),0)+isnull(sum(a.day03),0)+isnull(sum(a.day04),0)+isnull(sum(a.day05),0)+isnull(sum(a.day06),0)+isnull(sum(a.day07),0)+isnull(sum(a.day08),0)+isnull(sum(a.day09),0)+isnull(sum(a.day10),0)+isnull(sum(a.day11),0)+isnull(sum(a.day12),0),15,3),
       day99=str(isnull(sum(a.day99),0),15,3),
       diff=str(isnull(sum(a.day01),0)+isnull(sum(a.day02),0)+isnull(sum(a.day03),0)+isnull(sum(a.day04),0)+isnull(sum(a.day05),0)+isnull(sum(a.day06),0)+isnull(sum(a.day07),0)+isnull(sum(a.day08),0)+isnull(sum(a.day09),0)+isnull(sum(a.day10),0)+isnull(sum(a.day11),0)+isnull(sum(a.day12),0) -isnull(sum(a.day99),0),15,3)
       from yact_bal a
       group by a.date
       having isnull(sum(a.day01),0)+isnull(sum(a.day02),0)+isnull(sum(a.day03),0)+isnull(sum(a.day04),0)+isnull(sum(a.day05),0)+
              isnull(sum(a.day06),0)+isnull(sum(a.day07),0)+isnull(sum(a.day08),0)+isnull(sum(a.day09),0)+isnull(sum(a.day10),0)+
              isnull(sum(a.day11),0)+isnull(sum(a.day12),0) -
              isnull(sum(a.day99),0) <> 0
       order by a.date
