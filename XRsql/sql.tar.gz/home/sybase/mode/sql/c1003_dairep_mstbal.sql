/* mstbalrep against dairep balance check - tillbl */
/*
----each----:[dairep.till_bl]
----each----:[mstbalrep.tillbl][#ymstbalrep.tillbl]
*/
select 
       bdate=convert(char(4),datepart(year,b.bdate))+'/'+substring(convert(char(3),datepart(month,b.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,b.bdate)+100),2,2),
       dairep_tillbl=str((select isnull(sum(a.till_bl),0) from dairep a where  a.class='02000' or a.class='03000'),15,3),
       mstbal_tillbl=str((select isnull(sum(a.tillbl),0) from mstbalrep a),15,3),
       diff=str((select isnull(sum(a.till_bl),0) from dairep a where  a.class='02000' or a.class='03000')-(select isnull(sum(a.tillbl),0) from mstbalrep a),15,3)
       from accthead b
       where ((select isnull(sum(a.till_bl),0) from dairep a where  a.class='02000' or a.class='03000')-(select isnull(sum(a.tillbl),0) from mstbalrep a)) <> 0 
              and (select sum(a.tillbl) from mstbalrep a) is not null

