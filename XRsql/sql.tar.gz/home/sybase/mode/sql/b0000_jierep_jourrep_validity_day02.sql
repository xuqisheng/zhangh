/* jierep_jourrep definition validity - day02 */
/*
   missing_classes_count        : Estimated count of codes which are not in jourrep
   conflict_with_impindex_count : Estimated count of codes which are in jourrep but the corresponding impindex are not empty
*/
/*
----each----:[jierep.class]
----each----:[jierep_jourrep.class][jierep_jourrep.descript][jierep_jourrep.day02]
----each----:[jourrep.class][jourrep.impindex]
*/
select a.class,a.descript,a.day02,
       missing_classes_count
       = (char_length(rtrim(a.day02)) - (select isnull(sum(char_length(rtrim(c.class))+1),0) from jourrep c where rtrim(a.day02)+'+' like '%[-+]'+rtrim(c.class)+'[-+]%'))/7,
       conflict_with_impindex_count
       = (select isnull(sum(char_length(rtrim(c.class))+1),0) from jourrep c where rtrim(c.impindex) is not null and rtrim(a.day02)+'+' like '%[-+]'+rtrim(c.class)+'[-+]%')/7
       from jierep_jourrep a
       where exists(select b.class from jierep b where b.class = a.class)
             and rtrim(a.day02) is not null
             and (select isnull(sum(char_length(rtrim(c.class))+1),0) from jourrep c where rtrim(c.impindex) is null and rtrim(a.day02)+'+' like '%[-+]'+rtrim(c.class)+'[-+]%') < char_length(rtrim(a.day02))
        order by a.class