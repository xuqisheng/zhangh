/* hgrpmst duplicate accnt check  */
/*
----each----:[hgrpmst.accnt]
----each----:[#pccode]
*/

select accnt,
       accnt_count = count(1),
       remark="duplicate accnt"
       from hgrpmst
       group by accnt
       having count(1) > 1

