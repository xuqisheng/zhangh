/* firstdays validity - completeness */
/*
----each----:[firstdays.firstday][firstdays.lastday][firstdays.year][firstdays.month]
*/
select
     firstday=convert(char(4),datepart(year,firstday))+'/'+substring(convert(char(3),datepart(month,firstday)+100),2,2)+'/'+substring(convert(char(3),datepart(day,firstday)+100),2,2),
     lastday =convert(char(4),datepart(year,lastday))+'/'+substring(convert(char(3),datepart(month,lastday)+100),2,2)+'/'+substring(convert(char(3),datepart(day,lastday)+100),2,2),
     next_firstday =convert(char(4),datepart(year,(select min(b.firstday) from firstdays b where b.firstday>=dateadd(dd,2,firstdays.lastday) and b.lastday >= dateadd(dd,1,firstdays.lastday))))+'/'+
                 substring(convert(char(3),datepart(month,(select min(b.firstday) from firstdays b where b.firstday>=dateadd(dd,2,firstdays.lastday) and b.lastday >= dateadd(dd,1,firstdays.lastday)))+100),2,2)+'/'+
                 substring(convert(char(3),datepart(day,(select min(b.firstday) from firstdays b where b.firstday>=dateadd(dd,2,firstdays.lastday) and b.lastday >= dateadd(dd,1,firstdays.lastday)))+100),2,2),
     remark = "date gap occurs between lastday and next firstday"
     from firstdays
     where firstdays.lastday < (select max(b.lastday) from firstdays b)
           and not exists (select 1 from firstdays b where b.firstday <= dateadd(dd,1,firstdays.lastday) and b.lastday >= dateadd(dd,1,firstdays.lastday))
     order by firstday