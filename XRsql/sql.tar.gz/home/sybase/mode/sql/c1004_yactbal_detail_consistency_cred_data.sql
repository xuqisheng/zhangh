/* yact_bal detail consistency check - cred data*/
/*
----each----:[yact_bal.date][yact_bal.accnt][yact_bal.name]
----each----:[yact_bal.cred01][yact_bal.cred02][yact_bal.cred03][yact_bal.cred04][yact_bal.cred05]
----each----:[yact_bal.cred99]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.accnt,a.name,
       a.cred01,a.cred02,a.cred03,a.cred04,a.cred05,
       sum01_05=str((a.cred01+a.cred02+a.cred03+a.cred04+a.cred05),15,3),
       a.cred99,
       diff=str((a.cred01+a.cred02+a.cred03+a.cred04+a.cred05)-a.cred99,15,3)
       from yact_bal a
       where (a.cred01+a.cred02+a.cred03+a.cred04+a.cred05)-a.cred99 <> 0
       order by a.date,a.accnt
