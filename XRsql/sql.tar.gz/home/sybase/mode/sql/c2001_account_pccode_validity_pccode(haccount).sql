/* haccount.pccode vs pccode.pccode - validity check  */
/*
----each----:[haccount.accnt][haccount.number][haccount.inumber][haccount.bdate][haccount.pccode][haccount.charge][haccount.credit]
----each----:[pccode.pccode]
*/

select accnt,number,inumber,
       bdate=convert(char(4),datepart(year,a.bdate))+'/'+substring(convert(char(3),datepart(month,a.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.bdate)+100),2,2),
       pccode,charge,credit,
       remark="haccount.pccode not defined in table pccode"
       from haccount a
       where not exists(select 1 from pccode b where a.pccode = b.pccode)
             and rtrim(a.pccode) is not null and a.pccode <> '9'
       order by a.accnt,a.number