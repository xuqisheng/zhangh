/* hmaster duplicate accnt check  */
/*
----each----:[hmaster.accnt]
----each----:[#pccode]
*/

select accnt,
       accnt_count = count(1),
       remark="duplicate accnt"
       from hmaster
       group by accnt
       having count(1) > 1
