/* phextroom definition - roomno validity */
/*
----each----:[phextroom.extno][phextroom.roomno][phextroom.rgid]
----each----:[rmsta.roomno]
*/
select phextroom_extno  = a.extno,
       phextroom_roomno = a.roomno,
       remark           = 'roomno not defined in rmsta'
       from phextroom a
       where a.rgid ='A' and not (exists(select 1 from rmsta b where b.roomno=a.roomno))
       order by a.extno