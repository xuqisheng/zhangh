/* paymth definition - codecls validity */
/*
----each----:[paymth.paycode][paymth.descript1][paymth.descript2][paymth.codecls]
----each----:[credcls.class]
----each----:[#basecode]
*/
select a.paycode,a.descript1,a.descript2,a.codecls,
       remark = 'codecls not in table credcls'
       from paymth a
       where not exists(select 1 from credcls b where b.class=a.codecls)
       order by a.paycode

