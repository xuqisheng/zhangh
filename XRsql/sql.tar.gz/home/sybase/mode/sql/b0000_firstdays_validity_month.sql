/* firstdays validity - month */
/*
----each----:[firstdays.firstday][firstdays.lastday][firstdays.year][firstdays.month]
*/
select
     firstday=convert(char(4),datepart(year,firstday))+'/'+substring(convert(char(3),datepart(month,firstday)+100),2,2)+'/'+substring(convert(char(3),datepart(day,firstday)+100),2,2),
     lastday =convert(char(4),datepart(year,lastday))+'/'+substring(convert(char(3),datepart(month,lastday)+100),2,2)+'/'+substring(convert(char(3),datepart(day,lastday)+100),2,2),
     year,month,
     remark = "month not between 1 and 12"
     from firstdays
     where not (month >=1 and month <= 12)
     order by firstday