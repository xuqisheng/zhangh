/* ygststa validty - nation check */
/*
----each----:[ygststa]
*/

select 
       date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.gclass,
       a.order_,
       a.nation,
       a.descript,
       remark = 'nation not in table countrycode'
       from ygststa a
       where rtrim(a.nation) is not null and not exists(select 1 from countrycode b where b.code=a.nation)
       order by a.date,a.gclass,a.order_,a.nation
