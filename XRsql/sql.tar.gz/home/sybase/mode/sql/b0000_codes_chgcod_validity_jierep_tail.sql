/* chgcod definition validity - jierep and tail */
/*
----each----:[chgcod.pccode][chgcod.servcode][chgcod.descript1][chgcod.descript2][chgcod.jierep][chgcod.tail]
----each----:[jierep.class][jierep.day01][jierep.day02][jierep.day03][jierep.day04]
----each----:[jierep.day05][jierep.day06][jierep.day07][jierep.day08][jierep.day09]
*/
select a.pccode,a.servcode,a.descript1,a.descript2,a.jierep,a.tail,
       remark = 'Missing corresponding row or column in jierep'
       from chgcod a
       where a.pccode not in ('01','02','03','05','06') and not (exists(select 1 from jierep b where b.class=a.jierep) and a.tail in ('01','02','03','04','05','06','07','08','09'))
             or a.pccode in ('01','02') and a.jierep not like '010%' and not (exists(select 1 from jierep b where b.class=a.jierep) and a.tail in ('01','02','03','04','05','06','07','08','09'))
       order by a.pccode,a.servcode