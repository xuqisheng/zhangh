/* ydairep detail consistency check */
/*
----each----:[ydairep.date][ydairep.class][ydairep.descript][ydairep.last_bl][ydairep.debit][ydairep.credit][ydairep.till_bl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       class,
       descript,
       last_bl=str(a.last_bl,15,3),
       debit=str(a.debit,15,3),
       credit=str(a.credit,15,3),
       tillbl_a=str(a.last_bl+a.debit-a.credit,15,3),
       tillbl_b=str(a.till_bl,15,3),
       tillbl_diff=str((a.last_bl+a.debit-a.credit) - a.till_bl,15,3)
       from ydairep a 
       where (a.class='02000' or a.class='03000') and (a.last_bl+a.debit-a.credit) - a.till_bl <> 0
       order by a.date,a.class
            