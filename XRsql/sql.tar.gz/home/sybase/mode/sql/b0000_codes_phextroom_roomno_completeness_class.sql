/* phextroom definition - roomno completeness */
/*
----each----:[rmsta.roomno]
----each----:[phextroom.roomno][phextroom.class]
*/
select rmsta_roomno = a.roomno,
       remark      = 'roomno not in phextroom'
       from rmsta a
       where not exists(select 1 from phextroom b where b.roomno=a.roomno and b.class ='01' )
       order by a.roomno