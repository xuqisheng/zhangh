/* firstdays validity - order */
/*
----each----:[firstdays.firstday][firstdays.lastday][firstdays.year][firstdays.month]
*/
select
     firstday=convert(char(4),datepart(year,firstday))+'/'+substring(convert(char(3),datepart(month,firstday)+100),2,2)+'/'+substring(convert(char(3),datepart(day,firstday)+100),2,2),
     lastday =convert(char(4),datepart(year,lastday))+'/'+substring(convert(char(3),datepart(month,lastday)+100),2,2)+'/'+substring(convert(char(3),datepart(day,lastday)+100),2,2),
     year,month,
     remark = "lastday should be greater than or equal to firstday"
     from firstdays
     where not (lastday >= firstday)
     order by firstday