/* jourrep definition validity - impindex */
/*
----each----:[jourrep.class][jourrep.descript][jourrep.impindex]
----each----:[audit_impdata.class]
*/
select 
       a.class,a.descript,a.impindex,remark = "Missing corresponding row in audit_impdata"
       from jourrep a
       where rtrim(a.impindex) is not null and not exists(select b.class from audit_impdata b where b.class = a.impindex)
       order by a.class