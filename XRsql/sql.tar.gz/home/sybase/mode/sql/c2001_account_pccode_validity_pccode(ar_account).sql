/* ar_account.pccode vs pccode.pccode - validity check  */
/*
----each----:[ar_account.ar_accnt][ar_account.ar_number][ar_account.ar_inumber][ar_account.bdate][ar_account.pccode][ar_account.charge][ar_account.credit]
----each----:[pccode.pccode]
*/

select ar_accnt,ar_number,ar_inumber,
       bdate=convert(char(4),datepart(year,a.bdate))+'/'+substring(convert(char(3),datepart(month,a.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.bdate)+100),2,2),
       pccode,charge,credit,
       remark="ar_account.pccode not defined in table pccode"
       from ar_account a
       where not exists(select 1 from pccode b where a.pccode = b.pccode)
             and rtrim(a.pccode) is not null and a.pccode <> '9'
       order by a.ar_accnt,a.ar_number