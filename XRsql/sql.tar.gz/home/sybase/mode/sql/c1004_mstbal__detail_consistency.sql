/* mstbalrep detail consistency check */
/* check if lastbl+charge-credit = tillbl for each account no in mstbalrep */
/*
----each----:[mstbalrep.accnt][mstbalrep.name][mstbalrep.sta][mstbalrep.lastbl][mstbalrep.charge][mstbalrep.credit][mstbalrep.tillbl]
*/
select bdate=convert(char(4),datepart(year,b.bdate))+'/'+substring(convert(char(3),datepart(month,b.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,b.bdate)+100),2,2),
       a.accnt,
       a.sta,
       a.name,
       a.lastbl,
       a.charge,
       a.credit,
       tillbl_a=str((a.lastbl+a.charge-a.credit),15,3),
       tillbl_b=str(a.tillbl,15,3),
       tillbl_diff=str((a.lastbl+a.charge-a.credit)-a.tillbl,15,3)
       from mstbalrep a,accthead b
       where (a.lastbl+a.charge-a.credit)-a.tillbl <> 0
       order by a.accnt
