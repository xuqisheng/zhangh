/* armst_till vs armst_last financial data check */
/* V10 - V603 */
/*
----each----:[#pccode]
----each----:[armst_till][armst_last]
*/

select 
       acctheaddate=convert(char(4),datepart(year,c.bdate))+'/'+substring(convert(char(3),datepart(month,c.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,c.bdate)+100),2,2),
       a.accnt,

       armst_till_lastcharge = a.rmb_od,
       armst_last_tillcharge = b.rmb_td,
       diff_charge          = a.rmb_od - b.rmb_td,

       armst_till_lastcredit = a.depr_oc+a.addor,
       armst_last_tillcredit = b.depr_tc+b.addtr,
       diff_credit          = (a.depr_oc+a.addor) - (b.depr_tc+b.addtr)

       from armst_till a,armst_last b,accthead c
       where a.accnt=b.accnt
             and (a.rmb_od - b.rmb_td <> 0  or (a.depr_oc+a.addor) - (b.depr_tc+b.addtr) <> 0)
       order by a.accnt

            