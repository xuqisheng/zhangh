/* ymstbalrep against ydairep - horizontal dc check */
/* debit-credit */
/*
----each----:[ydairep.date][ydairep.debit][ydairep.credit]
----each----:[ymstbalrep.date][ymstbalrep.charge][ymstbalrep.credit]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       dairep_d=str(isnull(sum(a.debit),0),15,3),
       dairep_c=str(isnull(sum(a.credit),0),15,3),
       mstbal_d=str((select isnull(sum(b.charge),0) from ymstbalrep b where a.date=b.date),15,3),
       mstbal_c=str((select isnull(sum(b.credit),0) from ymstbalrep b where a.date=b.date),15,3),
       diff_d  =str(isnull(sum(a.debit),0)-(select isnull(sum(b.charge),0) from ymstbalrep b where a.date=b.date),15,3),
       diff_c  =str(isnull(sum(a.credit),0)-(select isnull(sum(b.credit),0) from ymstbalrep b where a.date=b.date),15,3),
       diff_dc =str(isnull(sum(a.debit-a.credit),0)-(select isnull(sum(b.charge-b.credit),0) from ymstbalrep b where a.date=b.date),15,3)
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having (isnull(sum(a.debit),0)-(select isnull(sum(b.charge),0) from ymstbalrep b where a.date=b.date) <> 0
               or
               isnull(sum(a.credit),0)-(select isnull(sum(b.credit),0) from ymstbalrep b where a.date=b.date) <> 0 
              )
              and (select sum(b.charge-b.credit) from ymstbalrep b where a.date=b.date) is not null
       order by a.date
            