/* yact_bal summary consistency check - ttd data*/
/*
----each----:[yact_bal.date]
----each----:[yact_bal.ttd01][yact_bal.ttd02][yact_bal.ttd03][yact_bal.ttd04][yact_bal.ttd05][yact_bal.ttd06]
----each----:[yact_bal.ttd07][yact_bal.ttd08][yact_bal.ttd09][yact_bal.ttd10][yact_bal.ttd11][yact_bal.ttd12]
----each----:[yact_bal.ttd99]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       ttd01=str(isnull(sum(a.ttd01),0),15,3),
       ttd02=str(isnull(sum(a.ttd02),0),15,3),
       ttd03=str(isnull(sum(a.ttd03),0),15,3),
       ttd04=str(isnull(sum(a.ttd04),0),15,3),
       ttd05=str(isnull(sum(a.ttd05),0),15,3),
       ttd06=str(isnull(sum(a.ttd06),0),15,3),
       ttd07=str(isnull(sum(a.ttd07),0),15,3),
       ttd08=str(isnull(sum(a.ttd08),0),15,3),
       ttd09=str(isnull(sum(a.ttd09),0),15,3),
       ttd10=str(isnull(sum(a.ttd10),0),15,3),
       ttd11=str(isnull(sum(a.ttd11),0),15,3),
       ttd12=str(isnull(sum(a.ttd12),0),15,3),
       sum01_12=str(isnull(sum(a.ttd01),0)+isnull(sum(a.ttd02),0)+isnull(sum(a.ttd03),0)+isnull(sum(a.ttd04),0)+isnull(sum(a.ttd05),0)+isnull(sum(a.ttd06),0)+isnull(sum(a.ttd07),0)+isnull(sum(a.ttd08),0)+isnull(sum(a.ttd09),0)+isnull(sum(a.ttd10),0)+isnull(sum(a.ttd11),0)+isnull(sum(a.ttd12),0),15,3),
       ttd99=str(isnull(sum(a.ttd99),0),15,3),
       diff=str(isnull(sum(a.ttd01),0)+isnull(sum(a.ttd02),0)+isnull(sum(a.ttd03),0)+isnull(sum(a.ttd04),0)+isnull(sum(a.ttd05),0)+isnull(sum(a.ttd06),0)+isnull(sum(a.ttd07),0)+isnull(sum(a.ttd08),0)+isnull(sum(a.ttd09),0)+isnull(sum(a.ttd10),0)+isnull(sum(a.ttd11),0)+isnull(sum(a.ttd12),0) -isnull(sum(a.ttd99),0),15,3)
       from yact_bal a
       group by a.date
       having isnull(sum(a.ttd01),0)+isnull(sum(a.ttd02),0)+isnull(sum(a.ttd03),0)+isnull(sum(a.ttd04),0)+isnull(sum(a.ttd05),0)+
              isnull(sum(a.ttd06),0)+isnull(sum(a.ttd07),0)+isnull(sum(a.ttd08),0)+isnull(sum(a.ttd09),0)+isnull(sum(a.ttd10),0)+
              isnull(sum(a.ttd11),0)+isnull(sum(a.ttd12),0) -
              isnull(sum(a.ttd99),0) <> 0
       order by a.date
