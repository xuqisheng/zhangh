/* ycus_xf summary continuity check */
/*
----each----:[ycus_xf.date][ycus_xf.sta][ycus_xf.lastbl][ycus_xf.tillbl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       thisday_tillbl=str(sum(a.tillbl),15,3),
       nextday_lastbl=str((select sum(b.lastbl) from ycus_xf b where b.date = dateadd(dd,1,a.date) and rtrim(b.sta) is not null),15,3),
       diff=str(sum(a.tillbl) - (select sum(b.lastbl) from ycus_xf b where b.date = dateadd(dd,1,a.date) and rtrim(b.sta) is not null),15,3)
       from ycus_xf a 
       where a.date < (select c.bdate from accthead c) and rtrim(a.sta) is not null
       group by a.date
       having sum(a.tillbl) - (select sum(b.lastbl) from ycus_xf b where b.date = dateadd(dd,1,a.date) and rtrim(b.sta) is not null) <> 0
              or sum(a.tillbl) <> 0 and (select sum(b.lastbl) from ycus_xf b where b.date = dateadd(dd,1,a.date) and rtrim(b.sta) is not null) is null
       order by a.date
            