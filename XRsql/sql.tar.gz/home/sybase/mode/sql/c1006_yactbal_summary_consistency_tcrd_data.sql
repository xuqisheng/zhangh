/* yact_bal summary consistency check - tcrd data*/
/*
----each----:[yact_bal.date]
----each----:[yact_bal.tcrd01][yact_bal.tcrd02][yact_bal.tcrd03][yact_bal.tcrd04][yact_bal.tcrd05]
----each----:[yact_bal.tcrd99]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       tcrd01=str(isnull(sum(a.tcrd01),0),15,3),
       tcrd02=str(isnull(sum(a.tcrd02),0),15,3),
       tcrd03=str(isnull(sum(a.tcrd03),0),15,3),
       tcrd04=str(isnull(sum(a.tcrd04),0),15,3),
       tcrd05=str(isnull(sum(a.tcrd05),0),15,3),
       sum01_05=str(isnull(sum(a.tcrd01),0)+isnull(sum(a.tcrd02),0)+isnull(sum(a.tcrd03),0)+isnull(sum(a.tcrd04),0)+isnull(sum(a.tcrd05),0),15,3),
       tcrd99=str(isnull(sum(a.tcrd99),0),15,3),
       diff=str(isnull(sum(a.tcrd01),0)+isnull(sum(a.tcrd02),0)+isnull(sum(a.tcrd03),0)+isnull(sum(a.tcrd04),0)+isnull(sum(a.tcrd05),0) - isnull(sum(a.tcrd99),0),15,3)
       from yact_bal a
       group by a.date
       having isnull(sum(a.tcrd01),0)+isnull(sum(a.tcrd02),0)+isnull(sum(a.tcrd03),0)+isnull(sum(a.tcrd04),0)+isnull(sum(a.tcrd05),0) - isnull(sum(a.tcrd99),0) <> 0
       order by a.date
