/* pccode definition - deptno validity - credit part*/
/*
----each----:[pccode.pccode][pccode.descript][pccode.descript1][pccode.deptno]
----each----:[credcls.class]
*/
select a.pccode,a.descript,a.descript1,
       pccode_deptno = a.deptno,
       remark = "deptno not in table credcls"
       from pccode a
       where pccode >= '9' and not exists(select 1 from credcls b where b.class=a.deptno)
       order by a.pccode