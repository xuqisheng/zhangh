/* mstbalrep against jiedai of V3 balance check - tillbl */
/* V10 - V40                                             */
/*
----each----:[jiedai.till_bl1][jiedai.till_blo]
----each----:[mstbalrep.tillbl][#ymstbalrep.tillbl]
----each----:[#pccode][#ydairep.last_bl]

*/
select 
       bdate=convert(char(4),datepart(year,b.bdate))+'/'+substring(convert(char(3),datepart(month,b.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,b.bdate)+100),2,2),
       jiedai_tillbl1_plus_tillblo=str((select isnull(sum(a.till_bl1+a.till_blo),0) from jiedai a),15,3),
       mstbal_tillbl=str((select isnull(sum(a.tillbl),0) from mstbalrep a),15,3),
       diff=str((select isnull(sum(a.till_bl1+a.till_blo),0) from jiedai a)-(select isnull(sum(a.tillbl),0) from mstbalrep a),15,3)
       from accthead b
       where ((select isnull(sum(a.till_bl1+a.till_blo),0) from jiedai a)-(select isnull(sum(a.tillbl),0) from mstbalrep a)) <> 0 
              and (select sum(a.tillbl) from mstbalrep a) is not null

