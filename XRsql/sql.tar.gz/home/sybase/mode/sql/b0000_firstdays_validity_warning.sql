/* firstdays validity - warning */
/*
----each----:[firstdays.firstday][firstdays.lastday][firstdays.year][firstdays.month]
----each----:[accthead.bdate]
*/
select
     firstday=convert(char(4),datepart(year,firstday))+'/'+substring(convert(char(3),datepart(month,firstday)+100),2,2)+'/'+substring(convert(char(3),datepart(day,firstday)+100),2,2),
     lastday =convert(char(4),datepart(year,lastday))+'/'+substring(convert(char(3),datepart(month,lastday)+100),2,2)+'/'+substring(convert(char(3),datepart(day,lastday)+100),2,2),
     year,month,
     remark = "suggest defining more data"
     from firstdays
     where lastday = (select max(b.lastday) from firstdays b)
           and datediff(dd,(select bdate from accthead),(select max(b.lastday) from firstdays b)) < 100
     order by firstday
