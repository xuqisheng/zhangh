/* yjiedai of V3 continuity check */
/* V10 - V40                      */
/*
----each----:[yjiedai.date][yjiedai.last_bl1][yjiedai.last_blo][yjiedai.till_bl1][yjiedai.till_blo]
----each----:[#pccode][#ydairep.last_bl]
*/
/*
sum(a+b) and sum(a)+sum(b) are different!
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       thisday_tillbl1=str(sum(a.till_bl1),15,3),
       nextday_lastbl1=str((select sum(b.last_bl1) from yjiedai b where b.date = dateadd(dd,1,a.date)),15,3),
       diff_bl1=str(sum(a.till_bl1)-(select sum(b.last_bl1) from yjiedai b where b.date = dateadd(dd,1,a.date)),15,3),
       thisday_tillblo=str(sum(a.till_blo),15,3),
       nextday_lastblo=str((select sum(b.last_blo) from yjiedai b where b.date = dateadd(dd,1,a.date)),15,3),
       diff_blo=str(sum(a.till_blo)-(select sum(b.last_blo) from yjiedai b where b.date = dateadd(dd,1,a.date)),15,3)
       from yjiedai a where a.date < (select c.bdate from accthead c)
       group by a.date
       having 
              (sum(a.till_bl1)-(select sum(b.last_bl1) from yjiedai b where b.date = dateadd(dd,1,a.date)) <> 0 or sum(a.till_bl1) <> 0 and (select sum(b.last_bl1) from yjiedai b where b.date = dateadd(dd,1,a.date)) is null)
              or 
              (sum(a.till_blo)-(select sum(b.last_blo) from yjiedai b where b.date = dateadd(dd,1,a.date)) <> 0 or sum(a.till_blo) <> 0 and (select sum(b.last_blo) from yjiedai b where b.date = dateadd(dd,1,a.date)) is null)
       order by a.date
