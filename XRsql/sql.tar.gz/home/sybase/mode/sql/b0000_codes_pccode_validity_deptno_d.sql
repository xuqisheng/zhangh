/* pccode definition - deptno validity - charge part*/
/*
----each----:[pccode.pccode][pccode.descript][pccode.descript1][pccode.deptno]
----each----:[basecode.cat][basecode.code]
*/
select a.pccode,a.descript,a.descript1,
       pccode_deptno = a.deptno,
       remark = "deptno not in table basecode with cat='chgcod_deptno'"
       from pccode a
       where pccode < '9' and not exists(select 1 from basecode b where b.cat='chgcod_deptno' and b.code=a.deptno)
       order by a.pccode