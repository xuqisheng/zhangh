/* gststa1 validty - wfrom check - v3 */
/*
----each----:[gststa1]
----each----:[cntaclcode.dm][cntaclcode.descript]
*/

select 
       date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.gclass,
       a.wfrom,
       a.descript,
       remark = 'wfrom not in table cnaclcode'
       from gststa1 a
       where a.gclass='41' and rtrim(a.wfrom) is not null and not exists(select 1 from cntaclcode b where b.dm=a.wfrom)
       order by a.date,a.gclass,a.wfrom
