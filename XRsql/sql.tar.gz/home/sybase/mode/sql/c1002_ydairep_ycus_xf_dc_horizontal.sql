/* ycus_xf against ydairep - horizontal dc check */
/* debit-credit */
/*
----each----:[ydairep.date][ydairep.debit][ydairep.credit]
----each----:[ycus_xf.date][ycus_xf.sta][ycus_xf.dtl][ycus_xf.ctl][ycus_xf.sta]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       dairep_d=str(isnull(sum(a.debit),0),15,3),
       dairep_c=str(isnull(sum(a.credit),0),15,3),
       ycusxf_d=str((select isnull(sum(b.dtl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null),15,3),
       ycusxf_c=str((select isnull(sum(b.ctl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null),15,3),
       diff_d=str(isnull(sum(a.debit),0) - (select isnull(sum(b.dtl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null),15,3),
       diff_c=str(isnull(sum(a.credit),0) - (select isnull(sum(b.ctl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null),15,3),
       diff_dc=str(isnull(sum(a.debit-a.credit),0) - (select isnull(sum(b.dtl-b.ctl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null),15,3)
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having ( isnull(sum(a.debit),0) - (select isnull(sum(b.dtl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null)   <> 0 
                or isnull(sum(a.credit),0) - (select isnull(sum(b.ctl),0) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null) <> 0
              )
              and (select sum(b.dtl-b.ctl) from ycus_xf b where a.date=b.date and rtrim(b.sta) is not null) is not null
       order by a.date
