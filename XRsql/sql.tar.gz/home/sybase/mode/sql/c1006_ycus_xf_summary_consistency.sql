/* ycus_xf summary consistency check */
/*
----each----:[ycus_xf.date][ycus_xf.sta]
----each----:[ycus_xf.lastd][ycus_xf.lastc][ycus_xf.dtl][ycus_xf.ctl]
----each----:[ycus_xf.tilld][ycus_xf.tillc][ycus_xf.tillbl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),

       lastd=str(sum(a.lastd),15,3),
       lastc=str(sum(a.lastc),15,3),

       debit=str(sum(a.dtl),15,3),
       credit=str(sum(a.ctl),15,3),

       tilld_a=str(sum(a.lastd)+sum(a.dtl),15,3),
       tillc_a=str(sum(a.lastc)+sum(a.ctl),15,3),

       tilld_b=str(sum(a.tilld),15,3),
       tillc_b=str(sum(a.tillc),15,3),

       tilld_diff=str(sum(a.lastd)+sum(a.dtl)-sum(a.tilld),15,3),
       tillc_diff=str(sum(a.lastc)+sum(a.ctl)-sum(a.tillc),15,3),
       tillbl_diff=str(sum(a.lastd)+sum(a.dtl)-(sum(a.lastc)+sum(a.ctl)) - (sum(a.tilld)-sum(a.tillc)),15,3)

       from ycus_xf a where rtrim(a.sta) is not null
       group by a.date
       having sum(a.lastd)+sum(a.dtl)-sum(a.tilld) <> 0 or sum(a.lastc)+sum(a.ctl)-sum(a.tillc) <> 0
       order by a.date
