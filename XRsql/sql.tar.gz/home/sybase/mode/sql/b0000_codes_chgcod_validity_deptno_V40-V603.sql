/* chgcod definition - deptno validity */
/* V40 - V603                          */

/*
----each----:[chgcod.pccode][chgcod.servcode][chgcod.descript1][chgcod.descript2][chgcod.deptno]
----each----:[deptdef.deptno][deptdef.type]
----each----:[#basecode]
*/
select a.pccode,a.servcode,a.descript1,a.descript2,a.deptno,
       remark = "deptno not in table deptdef where type='0'"
       from chgcod a
       where a.pccode not in ('03','05','06') and not exists(select 1 from deptdef b where b.type='0' and b.deptno=a.deptno)
       order by a.pccode,a.servcode

