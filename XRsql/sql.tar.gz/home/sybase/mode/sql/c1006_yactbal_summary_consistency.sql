/* yact_bal summary consistency check */
/*
----each----:[yact_bal.date][yact_bal.lastbl][yact_bal.day99][yact_bal.cred99][yact_bal.tillbl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       lastbl=str(sum(a.lastbl),15,3),
       debit=str(sum(a.day99),15,3),
       credit=str(sum(a.cred99),15,3),
       tillbl_a=str(sum(a.lastbl+a.day99-a.cred99),15,3),
       tillbl_b=str(sum(a.tillbl),15,3),
       tillbl_diff=str(sum((a.lastbl+a.day99-a.cred99) - a.tillbl),15,3)
       from yact_bal a
       group by a.date
       having sum((a.lastbl+a.day99-a.cred99) - a.tillbl) <> 0
       order by a.date
            