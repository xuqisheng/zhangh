/* yjiedai summary continuity check */
/*
----each----:[yjiedai.date][yjiedai.last_charge][yjiedai.last_credit][yjiedai.till_charge][yjiedai.till_credit]
*/
/*
sum(a+b) and sum(a)+sum(b) are different!
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       thisday_till_charge=str(sum(a.till_charge),15,3),
       nextday_last_charge=str((select sum(b.last_charge) from yjiedai b where b.date = dateadd(dd,1,a.date)),15,3),
       diff_charge=str(sum(a.till_charge)-(select sum(b.last_charge) from yjiedai b where b.date = dateadd(dd,1,a.date)),15,3),
       thisday_till_credit=str(sum(a.till_credit),15,3),
       nextday_last_credit=str((select sum(b.last_credit) from yjiedai b where b.date = dateadd(dd,1,a.date)),15,3),
       diff_credit=str(sum(a.till_credit)-(select sum(b.last_credit) from yjiedai b where b.date = dateadd(dd,1,a.date)),15,3)

       from yjiedai a where a.date < (select c.bdate from accthead c)
       group by a.date
       having 
              (sum(a.till_charge)-(select sum(b.last_charge) from yjiedai b where b.date = dateadd(dd,1,a.date)) <> 0 or sum(a.till_charge) <> 0 and (select sum(b.last_charge) from yjiedai b where b.date = dateadd(dd,1,a.date)) is null)
              or 
              (sum(a.till_credit)-(select sum(b.last_credit) from yjiedai b where b.date = dateadd(dd,1,a.date)) <> 0 or sum(a.till_credit) <> 0 and (select sum(b.last_credit) from yjiedai b where b.date = dateadd(dd,1,a.date)) is null)
       order by a.date
