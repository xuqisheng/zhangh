/* pccode definition validity - jierep and tail */
/*
----each----:[pccode.pccode][pccode.descript][pccode.descript1][pccode.jierep][pccode.tail]
----each----:[jierep.class][jierep.day01][jierep.day02][jierep.day03][jierep.day04]
----each----:[jierep.day05][jierep.day06][jierep.day07][jierep.day08][jierep.day09]
*/
select a.pccode,a.descript,a.descript1,a.jierep,a.tail,
       remark = 'Missing corresponding row or column in jierep'
       from pccode a
       where a.pccode <'9'  and a.jierep <> '010' and not (exists(select 1 from jierep b where b.class=a.jierep) and a.tail in ('01','02','03','04','05','06','07','08','09'))
       order by a.pccode