/* yact_bal detail consistency check */
/*
----each----:[yact_bal.date][yact_bal.accnt][yact_bal.name][yact_bal.sta]
----each----:[yact_bal.lastbl][yact_bal.day99][yact_bal.cred99][yact_bal.tillbl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.accnt,
       a.sta,
       a.name,
       lastbl=str(a.lastbl,15,3),
       debit=str(a.day99,15,3),
       credit=str(a.cred99,15,3),
       tillbl_a=str(a.lastbl+a.day99-a.cred99,15,3),
       tillbl_b=str(a.tillbl,15,3),
       tillbl_diff=str((a.lastbl+a.day99-a.cred99) - a.tillbl,15,3)
       from yact_bal a
       where (a.lastbl+a.day99-a.cred99) - a.tillbl <> 0
       order by a.date,a.accnt
            