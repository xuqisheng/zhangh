/* yact_bal detail consistency check - day data*/
/*
----each----:[yact_bal.date][yact_bal.accnt][yact_bal.name]
----each----:[yact_bal.day01][yact_bal.day02][yact_bal.day03][yact_bal.day04][yact_bal.day05][yact_bal.day06]
----each----:[yact_bal.day07][yact_bal.day08][yact_bal.day09][yact_bal.day10][yact_bal.day11][yact_bal.day12]
----each----:[yact_bal.day99]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.accnt,a.name,
       a.day01,a.day02,a.day03,a.day04,a.day05,a.day06,a.day07,a.day08,a.day09,a.day10,a.day11,a.day12,
       sum01_12=str((a.day01+a.day02+a.day03+a.day04+a.day05+a.day06+a.day07+a.day08+a.day09+a.day10+a.day11+a.day12),15,3),
       a.day99,
       diff=str((a.day01+a.day02+a.day03+a.day04+a.day05+a.day06+a.day07+a.day08+a.day09+a.day10+a.day11+a.day12)-a.day99,15,3)
       from yact_bal a
       where (a.day01+a.day02+a.day03+a.day04+a.day05+a.day06+a.day07+a.day08+a.day09+a.day10+a.day11+a.day12)-a.day99 <> 0
       order by a.date,a.accnt
   