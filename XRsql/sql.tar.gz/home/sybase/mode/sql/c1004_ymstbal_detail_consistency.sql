/* ymstbalrep detail consistency check */
/* check if lastbl+charge-credit = tillbl for each account no in ymstbalrep */
/*
----each----:[ymstbalrep.date][ymstbalrep.accnt][ymstbalrep.name][ymstbalrep.sta]
----each----:[ymstbalrep.lastbl][ymstbalrep.charge][ymstbalrep.credit][ymstbalrep.tillbl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.accnt,
       a.sta,
       a.name,
       a.lastbl,
       a.charge,
       a.credit,
       tillbl_a=str((a.lastbl+a.charge-a.credit),15,3),
       tillbl_b=str(a.tillbl,15,3),
       tillbl_diff=str((a.lastbl+a.charge-a.credit)-a.tillbl,15,3)
       from ymstbalrep a
       where (a.lastbl+a.charge-a.credit)-a.tillbl <> 0
       order by a.date,a.accnt
