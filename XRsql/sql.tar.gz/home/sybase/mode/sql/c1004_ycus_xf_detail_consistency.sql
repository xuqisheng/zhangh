/* ycus_xf detail consistency check */
/*
----each----:[ycus_xf.date][ycus_xf.accnt][ycus_xf.sta]
----each----:[ycus_xf.lastd][ycus_xf.lastc][ycus_xf.dtl][ycus_xf.ctl]
----each----:[ycus_xf.tilld][ycus_xf.tillc][ycus_xf.sta]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.accnt,
       a.sta,

       lastd=str(a.lastd,15,3),
       lastc=str(a.lastc,15,3),

       debit=str(a.dtl,15,3),
       credit=str(a.ctl,15,3),

       tilld_a=str(a.lastd+a.dtl,15,3),
       tillc_a=str(a.lastc+a.ctl,15,3),

       tilld_b=str(a.tilld,15,3),
       tillc_b=str(a.tillc,15,3),

       tilld_diff=str((a.lastd+a.dtl) - a.tilld ,15,3),
       tillc_diff=str((a.lastc+a.ctl) - a.tillc,15,3),
       tillbl_diff=str((a.lastd-a.lastc+a.dtl-a.ctl) - a.tillbl,15,3)

       from ycus_xf a
       where ((a.lastd+a.dtl) - a.tilld <> 0 or (a.lastc+a.ctl) - a.tillc <> 0) and rtrim(a.sta) is not null
       order by a.date,a.accnt
