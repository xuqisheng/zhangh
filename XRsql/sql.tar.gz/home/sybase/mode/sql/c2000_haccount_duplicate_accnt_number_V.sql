/* haccount duplicate accnt+number check  */
/*
----each----:[haccount.accnt][haccount.number]
----each----:[#pccode]
*/

select accnt,number,
       accnt_number_count = count(1),
       remark="duplicate accnt+number"
       from haccount
       group by accnt,number
       having count(1) > 1
