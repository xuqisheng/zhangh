/* mktcode definition validity - jierep */
/*
----each----:[mktcode.code][mktcode.descript][mktcode.descript1][mktcode.jierep]
----each----:[jierep.class][jierep.day01][jierep.day02][jierep.day03][jierep.day04][jierep.day05][jierep.day06][jierep.day07][jierep.day08][jierep.day09]
*/
select a.code,a.descript,a.descript1,a.jierep,
       remark = 'Missing corresponding row or column in jierep'
       from mktcode a
       where not exists(select 1 from jierep b where b.class=a.jierep)
       order by a.code