/* har_account.pccode vs pccode.pccode - validity check  */
/*
----each----:[har_account.ar_accnt][har_account.ar_number][har_account.ar_inumber][har_account.bdate][har_account.pccode][har_account.charge][har_account.credit]
----each----:[pccode.pccode]
*/

select ar_accnt,ar_number,ar_inumber,
       bdate=convert(char(4),datepart(year,a.bdate))+'/'+substring(convert(char(3),datepart(month,a.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.bdate)+100),2,2),
       pccode,charge,credit,
       remark="har_account.pccode not defined in table pccode"
       from har_account a
       where not exists(select 1 from pccode b where a.pccode = b.pccode)
             and rtrim(a.pccode) is not null and a.pccode <> '9'
       order by a.ar_accnt,a.ar_number