/* ycus_xf - create an index indexhry */
/*
----each----:[ycus_xf.date][ycus_xf.accnt][ycus_xf.tillbl]
*/
if not exists(select 1 from sysindexes where name='indexhry' and object_name(id)='ycus_xf')
   create unique index indexhry on ycus_xf(accnt,date)
