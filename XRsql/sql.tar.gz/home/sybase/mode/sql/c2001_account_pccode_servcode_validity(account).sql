/* account.pccode+account.servcode vs chgcod.pccode+chgcod.servcode - validity check  */
/*
----each----:[account.accnt][account.number][account.inumber][account.bdate][account.pccode][account.servcode][account.charge][account.credit]
----each----:[chgcod.pccode][chgcod.servcode]
*/

select accnt,number,inumber,
       bdate=convert(char(4),datepart(year,a.bdate))+'/'+substring(convert(char(3),datepart(month,a.bdate)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.bdate)+100),2,2),
       pccode,servcode,charge,credit,
       remark="account.pccode+account.servcode not defined in table chgcod"
       from account a
       where not exists(select 1 from chgcod b where a.pccode = b.pccode and a.servcode = b.servcode)
       order by a.accnt,a.number