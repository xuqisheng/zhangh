/* ydairep summary consistency check */
/*
----each----:[ydairep.date][ydairep.last_bl][ydairep.debit][ydairep.credit][ydairep.till_bl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       last_bl=str(sum(a.last_bl),15,3),
       debit=str(sum(a.debit),15,3),
       credit=str(sum(a.credit),15,3),
       tillbl_a=str(sum(a.last_bl+a.debit-a.credit),15,3),
       tillbl_b=str(sum(a.till_bl),15,3),
       tillbl_diff=str(sum((a.last_bl+a.debit-a.credit) - a.till_bl),15,3)
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having sum((a.last_bl+a.debit-a.credit) - a.till_bl) <> 0
       order by a.date
            