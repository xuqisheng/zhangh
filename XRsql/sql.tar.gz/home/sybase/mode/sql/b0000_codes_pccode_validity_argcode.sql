/* pccode definition - argcode validity */
/*
----each----:[pccode.pccode][pccode.descript][pccode.descript1][pccode.argcode]
----each----:[argcode.argcode]
*/
select a.pccode,a.descript,a.descript1,
       pccode_argcode = a.argcode,
       remark = 'argcode not in table argcode'
       from pccode a
       where not exists(select 1 from argcode b where b.argcode=a.argcode)
       order by a.pccode