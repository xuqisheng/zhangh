/* ygststa against ygststa1 check */
/*
----each----:[gststa.dgc][#gststa.dmc]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.gclass,descript=(select c.descript from ygststa c where c.date=a.date and c.gclass=a.gclass and rtrim(c.order_) is null),
                       fit=isnull(sum(a.dtc),0),
                       grp=isnull(sum(a.dgc),0),
                       fit1=(select isnull(sum(b.dtc),0) from ygststa1 b where a.date=b.date and ((a.gclass='1' and b.gclass='10') or
                                  (a.gclass='2' and (b.gclass='40' or b.gclass='60')) or
                                  (a.gclass='3' and b.gclass='50') or 
                                  (a.gclass='4' and b.gclass='20'))),
                       grp1=(select isnull(sum(b.dgc),0) from ygststa1 b where a.date=b.date and ((a.gclass='1' and b.gclass='10') or
                                  (a.gclass='2' and (b.gclass='40' or b.gclass='60')) or
                                  (a.gclass='3' and b.gclass='50') or 
                                  (a.gclass='4' and b.gclass='20'))),
                       Diff_fit=isnull(sum(a.dtc),0) - 
                                  (select isnull(sum(b.dtc),0) from ygststa1 b where a.date=b.date and ((a.gclass='1' and b.gclass='10') or
                                  (a.gclass='2' and (b.gclass='40' or b.gclass='60')) or
                                  (a.gclass='3' and b.gclass='50') or 
                                  (a.gclass='4' and b.gclass='20'))),
                       Diff_grp=isnull(sum(a.dgc),0) -
                                  (select isnull(sum(b.dgc),0) from ygststa1 b where a.date=b.date and ((a.gclass='1' and b.gclass='10') or
                                  (a.gclass='2' and (b.gclass='40' or b.gclass='60')) or
                                  (a.gclass='3' and b.gclass='50') or 
                                  (a.gclass='4' and b.gclass='20')))
                       from ygststa a
                       where (a.gclass='1') or
                              (a.gclass='2') or 
                              (a.gclass='3') or 
                              (a.gclass='4' and rtrim(a.order_) is null)
                             group by a.date,a.gclass
                             having isnull(sum(a.dtc),0) - 
                                  (select isnull(sum(b.dtc),0) from ygststa1 b where a.date=b.date and ((a.gclass='1' and b.gclass='10') or
                                   (a.gclass='2' and (b.gclass='40' or b.gclass='60')) or
                                   (a.gclass='3' and b.gclass='50') or 
                                   (a.gclass='4' and b.gclass='20'))) <> 0 or 
                                  isnull(sum(a.dgc),0) -
                                  (select isnull(sum(b.dgc),0) from ygststa1 b where a.date=b.date and ((a.gclass='1' and b.gclass='10') or
                                   (a.gclass='2' and (b.gclass='40' or b.gclass='60')) or
                                   (a.gclass='3' and b.gclass='50') or 
                                   (a.gclass='4' and b.gclass='20'))) <> 0
                             order by a.date,a.gclass
