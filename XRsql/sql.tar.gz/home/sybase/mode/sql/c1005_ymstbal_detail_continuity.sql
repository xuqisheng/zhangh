/* ymstbalrep detail continuity check */
/*
----each----:[ymstbalrep.date][ymstbalrep.accnt][ymstbalrep.name][ymstbalrep.sta]
----each----:[ymstbalrep.lastbl][ymstbalrep.tillbl]
*/
select a.accnt,
       a.sta,
       a.name,
       date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       thisday_tillbl=str(a.tillbl,15,3),
       nextday_lastbl=str((select b.lastbl from ymstbalrep b where a.accnt=b.accnt and b.date = dateadd(dd,1,a.date)),15,3),
       diff=str(a.tillbl-(select sum(b.lastbl) from ymstbalrep b where a.accnt=b.accnt and b.date = dateadd(dd,1,a.date)),15,3)
       from ymstbalrep a
       where a.date < (select c.bdate from accthead c) and 
             (a.tillbl <> 0 and (select sum(b.lastbl) from ymstbalrep b where a.accnt=b.accnt and b.date = dateadd(dd,1,a.date)) is null or
              a.tillbl-(select sum(b.lastbl) from ymstbalrep b where a.accnt=b.accnt and b.date = dateadd(dd,1,a.date)) <> 0
             )
       order by a.accnt,a.date