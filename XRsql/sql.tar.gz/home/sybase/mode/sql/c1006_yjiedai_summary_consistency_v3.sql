/* yjiedai summary consistency check */
/* V10 - V40                         */
/*
----each----:[yjiedai.date]
----each----:[yjiedai.last_bl1][yjiedai.last_blo]
----each----:[yjiedai.till_bl1][yjiedai.till_blo]
----each----:[yjiedai.debit_1][yjiedai.debit_o]
----each----:[yjiedai.credit_1][yjiedai.credit_o]
----each----:[#pccode][#ydairep.last_bl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       last_bl1,debit_1,credit_1,
       till_bl1_a =str( last_bl1+debit_1-credit_1,15,3),
       till_bl1_b =str( till_bl1,15,3),
       diff_bl1   =str( last_bl1+debit_1-credit_1 - till_bl1,15,3),
       last_blo,debit_o,credit_o,
       till_blo_a =str( last_blo+debit_o-credit_o,15,3),
       till_blo_b =str( till_blo,15,3),
       diff_blo   =str( last_blo+debit_o-credit_o - till_blo,15,3)
       from yjiedai a
       where last_bl1+debit_1-credit_1 <> till_bl1 or last_blo+debit_o-credit_o <> till_blo
       order by a.date
