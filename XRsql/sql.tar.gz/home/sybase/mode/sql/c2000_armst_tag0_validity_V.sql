/* armst tag0 check  */
/*
----each----:[armst.tag0][artagcode]
----each----:[#pccode]
*/

select accnt,tag0,
       remark="rtrim(tag0) is null or tag0 not in table artagcode"
       from armst
       where rtrim(tag0) is null or not exists (select 1 from artagcode a where a.code=armst.tag0)
       order by accnt