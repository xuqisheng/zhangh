/* yjierep against ydairep check*/
/*
----each----:[yjierep.date][yjierep.class][yjierep.day99][yjierep.month99]
----each----:[ydairep.date][ydairep.class][ydairep.sumcre][ydairep.sumcrem]
*/
select 
       date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       a.day99,a.month99,b.sumcre,b.sumcrem,
       Diff_daysum=str(a.day99-b.sumcre,15,3),
       Diff_monthsum=str(a.month99-b.sumcrem,15,3)
       from yjierep a,ydairep b
       where a.date = b.date
             and a.class=(select max(c.class) from yjierep c where c.date=a.date and c.class like '%[0-9]') 
             and b.class=(select max(c.class) from ydairep c where c.date=b.date and c.class like '%[0-9]')
             and (a.day99 <> b.sumcre or a.month99 <> b.sumcrem)
       order by a.date