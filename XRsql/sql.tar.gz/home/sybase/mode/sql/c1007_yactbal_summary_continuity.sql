/* yact_bal summary continuity check */
/*
----each----:[yact_bal.date][yact_bal.lastbl][yact_bal.tillbl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       thisday_tillbl=str(sum(a.tillbl),15,3),
       nextday_lastbl=str((select sum(b.lastbl) from yact_bal b where b.date = dateadd(dd,1,a.date)),15,3),
       diff=str(sum(a.tillbl) - (select sum(b.lastbl) from yact_bal b where b.date = dateadd(dd,1,a.date)),15,3)
       from yact_bal a
       where a.date < (select c.bdate from accthead c)
       group by a.date
       having sum(a.tillbl) - (select sum(b.lastbl) from yact_bal b where b.date = dateadd(dd,1,a.date)) <> 0
              or sum(a.tillbl) <> 0 and (select sum(b.lastbl) from yact_bal b where b.date = dateadd(dd,1,a.date)) is null
       order by a.date
            