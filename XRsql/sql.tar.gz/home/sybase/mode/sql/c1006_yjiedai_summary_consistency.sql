/* yjiedai summary consistency check */
/*
----each----:[yjiedai.date][yjiedai.last_charge][yjiedai.charge][yjiedai.till_charge][yjiedai.last_credit][yjiedai.credit][yjiedai.till_credit][yjiedai.apply]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       last_charge   =str(sum(a.last_charge),15,3),
       charge        =str(sum(a.charge),15,3),
       apply         =str(sum(a.apply),15,3),
       till_charge_a =str(sum(a.last_charge+a.charge-a.apply),15,3),
       till_charge_b =str(sum(a.till_charge),15,3),
       diff_charge   =str(sum(a.last_charge+a.charge-a.apply-a.till_charge),15,3),
       last_credit   =str(sum(a.last_credit),15,3),
       credit        =str(sum(a.credit),15,3),
       till_credit_a =str(sum(a.last_credit+a.credit-a.apply),15,3),
       till_credit_b =str(sum(a.till_credit),15,3),
       diff_credit   =str(sum(a.last_credit+a.credit-a.apply-a.till_credit),15,3),
       diff_balance  =str(sum((a.last_charge-a.last_credit)+(a.charge-a.credit)-(a.till_charge-a.till_credit)),15,3)
       from yjiedai a
       group by a.date
       having sum(a.last_charge+a.charge-a.apply-a.till_charge) <> 0 or sum(a.last_credit+a.credit-a.apply-a.till_credit) <> 0
       order by a.date
            