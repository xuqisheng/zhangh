/* yjiedai against ydairep balance check - tillbl */
/*
----each----:[ydairep.date][ydairep.till_bl]
----each----:[yjiedai.date][yjiedai.till_charge][yjiedai.till_credit]
*/

select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       dairep=str(isnull(sum(a.till_bl),0),15,3),
       jiedai=str((select isnull(sum(b.till_charge-b.till_credit),0) from yjiedai b where a.date = b.date),15,3),
       diff=str(isnull(sum(a.till_bl),0)-(select isnull(sum(b.till_charge-b.till_credit),0) from yjiedai b where a.date = b.date),15,3)
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having isnull(sum(a.till_bl),0)-(select isnull(sum(b.till_charge-b.till_credit),0) from yjiedai b where a.date = b.date) <> 0
              and (select sum(b.till_charge-b.till_credit) from yjiedai b where a.date=b.date) is not null
       order by a.date            