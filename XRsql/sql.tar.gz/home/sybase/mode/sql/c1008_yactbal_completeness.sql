/* yact_bal against ydairep - completeness check  */
/*
----each----:[ydairep.date][ydairep.last_bl][ydairep.debit][ydairep.credit][ydairep.till_bl]
----each----:[yact_bal.date]
*/

select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       remark='Missing balance data'
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having sum(abs(a.last_bl)+abs(a.debit)+abs(a.credit)+abs(a.till_bl)) <> 0
              and not exists(select 1 from yact_bal b where a.date = b.date)
              and datediff(dd,a.date,(select max(b.date) from yact_bal b)) <= 30
              and exists(select 1 from yact_bal b)
       order by a.date            