/* pccode definition - deptno6 validity - charge part*/
/*
----each----:[pccode.pccode][pccode.descript][pccode.descript1][pccode.deptno6]
----each----:[basecode.cat][basecode.code]
*/
select a.pccode,a.descript,a.descript1,
       pccode_deptno6 = a.deptno6,
       remark = "deptno6 not in table basecode with cat='chgcod_deptno6'"
       from pccode a
       where pccode < '9' and not exists(select 1 from basecode b where b.cat='chgcod_deptno6' and b.code=a.deptno6)
       order by a.pccode