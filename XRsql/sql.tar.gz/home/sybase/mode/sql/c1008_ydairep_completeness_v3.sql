/* ydairep of V3 - completeness check  */
/*
----each----:[ydairep.date][#ydairep.last_bl][#ydairep.till_bl]
*/

select remark             = "Missing ydairep data",
       from_inclusive    = convert(char(4),datepart(year,dateadd(dd,1,a.date)))+'/'+substring(convert(char(3),datepart(month,dateadd(dd,1,a.date))+100),2,2)+'/'+substring(convert(char(3),datepart(day,dateadd(dd,1,a.date))+100),2,2),
       to_inclusive      = convert(char(4),datepart(year,isnull((select min(dateadd(dd,-1,b.date)) from ydairep b where b.date > a.date),(select c.bdate from accthead c))))+'/'+substring(convert(char(3),datepart(month,isnull((select min(dateadd(dd,-1,b.date)) from ydairep b where b.date > a.date),(select c.bdate from accthead c)))+100),2,2)+'/'+substring(convert(char(3),datepart(day,isnull((select min(dateadd(dd,-1,b.date)) from ydairep b where b.date > a.date),(select c.bdate from accthead c)))+100),2,2)
       from ydairep a
       group by a.date
       having dateadd(dd,1,a.date) <= (select c.bdate from accthead c) and not exists(select 1 from ydairep d where dateadd(dd,1,a.date) = d.date)
       order by a.date