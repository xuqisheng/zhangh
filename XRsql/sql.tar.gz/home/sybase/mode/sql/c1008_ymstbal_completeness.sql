/* ymstbalrep against ydairep - completeness check  */
/*
----each----:[ydairep.date][ydairep.last_bl][ydairep.debit][ydairep.credit][ydairep.till_bl]
----each----:[ymstbalrep.date]
*/

select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       remark='Missing balance data'
       from ydairep a where (a.class='02000' or a.class='03000')
       group by a.date
       having sum(abs(a.last_bl)+abs(a.debit)+abs(a.credit)+abs(a.till_bl)) <> 0
              and not exists(select 1 from ymstbalrep b where a.date = b.date)
              and exists(select 1 from ymstbalrep b)
       order by a.date

