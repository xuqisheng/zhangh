/* ydairep detail continuity check */
/*
----each----:[ydairep.date][ydairep.class][ydairep.descript][ydairep.last_bl][ydairep.till_bl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       class,
       descript,
       thisday_tillbl=str(a.till_bl,15,3),
       nextday_lastbl=str((select sum(b.last_bl) from ydairep b where b.date = dateadd(dd,1,a.date) and b.class=a.class),15,3),
       diff=str(a.till_bl-(select sum(b.last_bl) from ydairep b where b.date = dateadd(dd,1,a.date) and b.class=a.class),15,3)
       from ydairep a
       where a.date < (select c.bdate from accthead c)
             and (a.class='02000' or a.class='03000')
             and (a.till_bl-(select sum(b.last_bl) from ydairep b where b.date = dateadd(dd,1,a.date) and b.class=a.class) <> 0
                  or (select sum(b.last_bl) from ydairep b where b.date = dateadd(dd,1,a.date) and b.class=a.class) is null
                 )
       order by a.date,a.class

            
