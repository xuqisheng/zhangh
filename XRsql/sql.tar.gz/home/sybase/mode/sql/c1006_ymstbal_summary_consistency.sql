/* ymstbalrep summary consistency check */
/*
----each----:[ymstbalrep.date][ymstbalrep.lastbl][ymstbalrep.charge][ymstbalrep.credit][ymstbalrep.tillbl]
*/
/*
sum(a+b) and sum(a)+sum(b) are different!
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       lastbl=str(sum(a.lastbl),15,3),
       charge=str(sum(a.charge),15,3),
       credit=str(sum(a.credit),15,3),
       tillbl_a=str(sum(a.lastbl)+sum(a.charge)-sum(a.credit),15,3),
       tillbl_b=str(sum(a.tillbl),15,3),
       diff_till=str((sum(a.lastbl)+sum(a.charge)-sum(a.credit))-sum(a.tillbl),15,3)
       from ymstbalrep a
       group by a.date
       having (sum(a.lastbl)+sum(a.charge)-sum(a.credit))-sum(a.tillbl) <>  0
       order by a.date
