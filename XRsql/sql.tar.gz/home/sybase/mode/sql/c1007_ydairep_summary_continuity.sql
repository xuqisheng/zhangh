/* ydairep summary continuity check */
/*
----each----:[ydairep.date][ydairep.last_bl][ydairep.till_bl]
*/
select date=convert(char(4),datepart(year,a.date))+'/'+substring(convert(char(3),datepart(month,a.date)+100),2,2)+'/'+substring(convert(char(3),datepart(day,a.date)+100),2,2),
       thisday_tillbl=str(sum(a.till_bl),15,3),
       nextday_lastbl=str((select sum(b.last_bl) from ydairep b where b.date = dateadd(dd,1,a.date) and (b.class='02000' or b.class='03000')),15,3),
       diff=str(sum(a.till_bl) - (select sum(b.last_bl) from ydairep b where b.date = dateadd(dd,1,a.date) and (b.class='02000' or b.class='03000')),15,3)
       from ydairep a
       where a.date < (select c.bdate from accthead c) and (a.class='02000' or a.class='03000')
       group by a.date
       having sum(a.till_bl) - (select sum(b.last_bl) from ydairep b where b.date = dateadd(dd,1,a.date) and (b.class='02000' or b.class='03000')) <> 0
              or sum(a.till_bl) <> 0 and (select sum(b.last_bl) from ydairep b where b.date = dateadd(dd,1,a.date) and (b.class='02000' or b.class='03000')) is null
       order by a.date
            
